package application;

import javax.swing.JOptionPane;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;

import java.net.URL;
import java.sql.*;
import java.util.List;
import java.util.ResourceBundle;


public class Register implements Initializable
{
	

	@FXML
	private TextField RRegno;
	
	@FXML
	private TextField RStudentname;

	@FXML
	private ComboBox<String> Rdept;
	
	@FXML
	private DatePicker Rdob;
	
	@FXML
	private TextArea Radd;
	ResultSet rs;
	

	@FXML
	public TableView<Modeltable>table;
	
	
	@FXML
	public TableColumn<Modeltable,String> trno;
	public TableColumn<Modeltable,String> tname;
	public TableColumn<Modeltable,String> tdept;
	public TableColumn<Modeltable,String> tdob;
	public TableColumn<Modeltable,String> tadd;
	
	ObservableList<Modeltable> oblist=FXCollections.observableArrayList();
	
	String Registernumber,Studentname,Department,DOB,Address; 
	
	
	
	public void initialize(URL location, ResourceBundle resources)
	
	{
		
		try {
		
			Class.forName("com.mysql.jdbc.Driver");
			Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/prabu", "root", "root");
			ResultSet rs =connect.createStatement().executeQuery("select * from student");
			
			while(rs.next()) 
			{
				oblist.add(new Modeltable(rs.getString("Registernumber"),rs.getString("Studentname"),rs.getString("Department"),rs.getString("DOB"),rs.getString("Address")));
			}
		} catch (SQLException | ClassNotFoundException e) {
			
			e.printStackTrace();
		}
		
		trno.setCellValueFactory(new PropertyValueFactory<>("Registernumber"));
		tname.setCellValueFactory(new PropertyValueFactory<>("Studentname"));
		tdept.setCellValueFactory(new PropertyValueFactory<>("Department"));
		tdob.setCellValueFactory(new PropertyValueFactory<>("DOB"));
		tadd.setCellValueFactory(new PropertyValueFactory<>("Address"));

		table.setItems(oblist);
		
		
		
		
	}



	
	public void ADD(ActionEvent event) throws Exception
	{

		
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/prabu", "root", "root");
			PreparedStatement pstmt = connect.prepareStatement("insert into student(`Registernumber`,`Studentname`,`Department`,`DOB`,`Address`) Values(?,?,?,?,?)");
			pstmt.setInt(1, Integer.valueOf(RRegno.getText()));
			pstmt.setString(2, RStudentname.getText());
			pstmt.setString(3, Rdept.getSelectionModel().getSelectedItem());
			pstmt.setDate(4, Date.valueOf(Rdob.getValue()));
			pstmt.setString(5, Radd.getText());
			@SuppressWarnings("unused")
			int rs = pstmt.executeUpdate();
			Alert alt = new Alert(AlertType.INFORMATION);
			alt.setTitle("Warning Message");
			alt.setContentText("Value Added successfully");
			alt.showAndWait();
			JOptionPane.showMessageDialog(null, "Inserted Successfully");
			pstmt.close();
			connect.close();
			
					
			}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		table.getItems().clear();
		refresh();
		
	
	}
		
	
	
	

	public void UPDATE(ActionEvent event) throws SQLException, ClassNotFoundException
	{
		Alert alert = new Alert(AlertType.CONFIRMATION);
		alert.setTitle("Confirmation Dialog");
		alert.setHeaderText("Do You Want To Edit");

		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/prabu", "root", "root");
			PreparedStatement pstmt = connect.prepareStatement("update student set Studentname=?,Department=?,DOB=?,Address=? where Registernumber=?");
			
			pstmt.setString(1, RStudentname.getText());
			pstmt.setString(2, Rdept.getSelectionModel().getSelectedItem());
			pstmt.setDate(3, Date.valueOf(Rdob.getValue()));
			pstmt.setString(4, Radd.getText());
			pstmt.setInt(5, Integer.valueOf(RRegno.getText()));
			@SuppressWarnings("unused")
			int rs = pstmt.executeUpdate();
			Alert alt = new Alert(AlertType.INFORMATION);
			alt.setTitle("Warning Message");
			alt.setContentText("Value update successfully");
			alt.showAndWait();

			JOptionPane.showMessageDialog(null, "Updated Successfully");
			pstmt.close();
			connect.close();
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
		table.getItems().clear();
		refresh();
	}
		
		
		public void DELETE(ActionEvent event) throws Exception
	{

			Alert alert = new Alert(AlertType.CONFIRMATION);
			alert.setTitle("Confirmation Dialog");
			alert.setHeaderText("Do You Want To Delete");

			try
			{
				Class.forName("com.mysql.jdbc.Driver");
				Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/prabu", "root", "root");
				PreparedStatement pstmt = connect.prepareStatement("delete from student where Registernumber=?");
				pstmt.setInt(1, Integer.valueOf(RRegno.getText()));
				@SuppressWarnings("unused")
				int rs = pstmt.executeUpdate();
				Alert alt = new Alert(AlertType.INFORMATION);
				alt.setTitle("Warning Message");
				alt.setContentText("Value Deleted successfully");
				alt.showAndWait();
				JOptionPane.showMessageDialog(null, "Deleted Successfully");
				pstmt.close();
				connect.close();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			table.getItems().clear();
			refresh();

	}
		
		

	public void CLEAR(ActionEvent event) throws Exception
	{
			RRegno.clear();
			RStudentname.clear();
			Rdept.getSelectionModel().clearSelection();;
			Rdob.getEditor().setText(null);
		    Radd.clear();
		    
	}
	
	
	
	public void refresh()
	{
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/prabu", "root", "root");
			ResultSet rs =connect.createStatement().executeQuery("select * from student");
			
			
			while(rs.next()) 
			{
				
				
				oblist.add(new Modeltable(rs.getString("Registernumber"),rs.getString("Studentname"),rs.getString("Department"),rs.getString("DOB"),rs.getString("Address")));
			}
			} 
		
		catch (SQLException | ClassNotFoundException e) 
		{
			
			e.printStackTrace();
		}

			
		    }
	
}

		



