package application;

public class Modeltable 
{
	
	String Registernumber,Studentname,Department,DOB,Address; 
	
	public Modeltable (String Registernumber,String Studentname,String Department,String DOB,String Address)
			{
				this.Registernumber=Registernumber;
				this.Studentname = Studentname;
				this.Department = Department;
				this.DOB = DOB;
				this.Address =Address;
			}
			
	//id set and get
		public String getRegisternumber()
		{
			return Registernumber;
		}
		public void setRegisternumber(String Registernumber)
		{
			this.Registernumber=Registernumber;
		}
		
		
		//name set and get
		
		public String getStudentname()
		{
			return Studentname;
		}
		public void setStudentname(String Studentname)
		{
			this.Studentname = Studentname;
		}
		
		
		public String getDepartment()
		{
			return Department;
		}
		public void setDepartment(String Department)
		{
			this.Department = Department;
		}
		
		
		public String getDOB()
		{
			return DOB;
		}
		public void setDOB(String DOB)
		{
			this.DOB = DOB;
		}
		


		public String getAddress()
		{
			return Address;
		}
		public void setAddress(String Address)
		{
			this.Address=Address;
		}
		

			
}



