package application;


import javax.swing.JOptionPane;

import javafx.event.ActionEvent;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;

import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import javafx.stage.Stage;



public class Maincontroller extends Main
{
	

	@FXML
	private Label lblabel;

	@FXML
	private TextField txtuser;
	
	@FXML
	private TextField txtpass;


	
	public void Signin(ActionEvent event)  throws Exception
	{
		if(txtuser.getText().equals("indhu")&& txtpass.getText().equals("indhu"))
		{
			JOptionPane.showMessageDialog(null, "Login Succesfull");
			Stage primaryStage=new Stage();
			Parent root = FXMLLoader.load(getClass().getResource("Register.fxml"));
			Scene scene = new Scene(root,1300,720);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.show();
					
		}
		else
		{
			JOptionPane.showMessageDialog(null, "Login Failure");
		}
		
	}



}
