-- MySQL dump 10.13  Distrib 5.7.12, for Win32 (AMD64)
--
-- Host: localhost    Database: sun
-- ------------------------------------------------------
-- Server version	5.7.16-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tariffentry`
--

DROP TABLE IF EXISTS `tariffentry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tariffentry` (
  `ClientName` varchar(45) DEFAULT NULL,
  `Code` varchar(45) DEFAULT NULL,
  `TownName` varchar(45) DEFAULT NULL,
  `perKg` double(20,2) DEFAULT NULL,
  `TownCode` varchar(45) DEFAULT NULL,
  `Fuel` double(20,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tariffentry`
--

LOCK TABLES `tariffentry` WRITE;
/*!40000 ALTER TABLE `tariffentry` DISABLE KEYS */;
INSERT INTO `tariffentry` VALUES ('M/s.CPC Diagonostics Pvt Ltd.','SL2','Mumbai',75.00,'Bom',0.00),('M/s.CPC Diagonostics Pvt Ltd.','SL2','New Delhi',75.00,'Del',0.00),('M/s.CPC Diagonostics Pvt Ltd.','SL2','Kolkatta',85.00,'Ccu',0.00),('M/s.CPC Diagonostics Pvt Ltd.','SL2','Pune',75.00,'Pnq',0.00),('M/s.CPC Diagonostics Pvt Ltd.','SL2','Ahmedabad',75.00,'Amd',0.00),('M/s.CPC Diagonostics Pvt Ltd.','SL2','Hydrabad',25.00,'hyd-surf',0.00),('M/s.CPC Diagonostics Pvt Ltd.','SL2','Hydrabad-Air',38.00,'Hyd-A',0.00),('M/s.CPC Diagonostics Pvt Ltd.','SL2','Puducherry',25.00,'Pdy',0.00),('M/s.CPC Diagonostics Pvt Ltd.','SL2','Salem',25.00,'Slm',0.00),('M/s.CPC Diagonostics Pvt Ltd.','SL2','Vijayawada',25.00,'Vjd',0.00),('M/s.CPC Diagonostics Pvt Ltd.','SL2','Salem',25.00,'Slm',0.00),('M/s.CPC Diagonostics Pvt Ltd.','SL2','Chennai',15.00,'Maa',0.00),('M/s.CPC Diagonostics Pvt Ltd.','SL2','Pune-Maa',75.00,'Pnq-Maa',0.00),('M/s.CPC Diagonostics Pvt Ltd.','SL2','Mumbai-Chennai',75.00,'Bom-Maa',0.00),('M/s.CPC Diagonostics Pvt Ltd','SL3','Hydrabad',23.00,'hyd-surf',0.00),('M/s.CPC Diagonostics Pvt Ltd','SL3','New Delhi',73.00,'Del',0.00),('M/s.CPC Diagonostics Pvt Ltd','SL3','Salem',23.00,'Slm',0.00),('xyz  abc lts','SL4','Mumbai',20.00,'Bom',1.00),('M/s. Proconnect Supply Chain Solutions Ltd.','SL1','Mumbai',32.00,'Bom',32.00),('M/s. Proconnect Supply Chain Solutions Ltd.','SL1','New Delhi',42.00,'Del',30.00),('M/s. Proconnect Supply Chain Solutions Ltd.','SL1','Kolkatta',42.00,'Ccu',30.00),('M/s. Proconnect Supply Chain Solutions Ltd.','SL1','Hydrabad',45.00,'Hyd',30.00),('M/s. Proconnect Supply Chain Solutions Ltd.','SL1','Pune',40.00,'Pnq',30.00),('M/s. Proconnect Supply Chain Solutions Ltd.','SL1','Ahmedabad',40.00,'Amd',30.00),('M/s. Proconnect Supply Chain Solutions Ltd.','SL1','Madurai',1000.00,'Ixm',30.00),('M/s.CPC Diagonostics Pvt Ltd.','SL2','Madurai',25.00,'Ixm',0.00),('M/s.CPC Diagonostics Pvt Ltd.','SL2','Salem',25.00,'Slm',0.00),('M/s.CPC Diagonostics Pvt Ltd.','SL2','Coimbatore',25.00,'Cjb',0.00),('M/s.CPC Diagonostics Pvt Ltd.','SL2','Coimbatore',25.00,'Cjb',0.00),('M/s.CPC Diagonostics Pvt Ltd.','SL2','Madurai-maa',25.00,'ixm-maa',0.00),('M/s.CPC Diagonostics Pvt Ltd.','SL2','Delhi-Maa',75.00,'Del-maa',0.00),('M/s.CPC Diagonostics Pvt Ltd','SL3','Hydrabad-Air',36.00,'Hyd-A',0.00),('M/s.CPC Diagonostics Pvt Ltd','SL3','Mumbai',73.00,'Bom',0.00),('M/s.CPC Diagonostics Pvt Ltd.','SL2','Tirunelveli',25.00,'Tvl',0.00),('M/s.CPC Diagonostics Pvt Ltd.','SL2','Thanjavur',25.00,'tnl',0.00),('M/s.CPC Diagonostics Pvt Ltd.','SL2',NULL,25.00,'GTR',0.00),('M/s.CPC Diagonostics Pvt Ltd.','SL2','KARNOOL',30.00,'KARNOOL',0.00),('M/s.CPC Diagonostics Pvt Ltd','SL3','GUNTUR',23.00,'GTR',0.00),('M/s.CPC Diagonostics Pvt Ltd.','SL2','Madurai',25.00,'ixm',0.00),('M/s.CPC Diagonostics Pvt Ltd','SL3','Tirunelveli',23.00,'Tvl',0.00),('M/s.CPC Diagonostics Pvt Ltd','SL3','Vijayawada',23.00,'Vjd',0.00),('M/s.CPC Diagonostics Pvt Ltd','SL3','Thanjavur',23.00,'tnl',0.00),('M/s.CPC Diagonostics Pvt Ltd','SL3','Thanjavur',23.00,'tnl',0.00),('M/s.CPC Diagonostics Pvt Ltd','SL3','Puducherry',23.00,'Pdy',0.00),('M/s.CPC Diagonostics Pvt Ltd.','SL2','Mayiladuthurai',25.00,'mayil',0.00),('M/s.CPC Diagonostics Pvt Ltd','SL3','Kolkatta',83.00,'Ccu',0.00),('Mr.Manivannan','SL4','Kerala',12.00,'kerala',0.00),('Mr.Manivannan','SL4','Local',12.00,'Local',0.00),('Mr.Manivannan','SL4','Tamilnadu',12.00,'TN',0.00),('M/s.CPC Diagonostics Pvt Ltd','SL3','vjd-maa',23.00,'vjd-maa',0.00),('M/S.Quick  mail solutions (P) Ltd','SL5','Kerala',12.00,'kerala',0.00),('M/S.Quick  mail solutions (P) Ltd','SL5','Tamilnadu',12.00,'TN',0.00),('M/S.Quick  mail solutions (P) Ltd','SL5','Chennai',12.00,'Maa',0.00),('M/s.CPC Diagonostics Pvt Ltd','SL3','Thanjavur',23.00,'tnl',0.00),('M/s.CPC Diagonostics Pvt Ltd.','SL2','Bangalore',25.00,'Blr',0.00),('M/s.CPC Diagonostics Pvt Ltd','SL3','Mayiladuthurai',23.00,'mayil',0.00),('M/s.CPC Diagonostics Pvt Ltd','SL3','Pune',73.00,'Pnq',0.00),('M/s.CPC Diagonostics Pvt Ltd','SL3','warangal',25.00,'war',0.00),('M/s.CPC Diagonostics Pvt Ltd.','SL2','Visakapatnam',25.00,'vtz',0.00),('M/s.CPC Diagonostics Pvt Ltd','SL3','slm-maa',23.00,'slm-maa',0.00);
/*!40000 ALTER TABLE `tariffentry` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-01-02 15:02:26
