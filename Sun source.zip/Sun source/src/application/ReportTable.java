package application;

import javafx.beans.property.DoubleProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class ReportTable {
	public SimpleIntegerProperty serial;
	public SimpleStringProperty billno;
	public SimpleStringProperty date;
	public SimpleStringProperty consignor;
	public SimpleStringProperty place;
	public SimpleStringProperty phoneno;
	public SimpleDoubleProperty weight;
	public SimpleIntegerProperty box;
	public SimpleDoubleProperty amount;
	public SimpleDoubleProperty fuelsurcharge;
	public SimpleDoubleProperty tbamount;
	public SimpleDoubleProperty tax;	
	public SimpleDoubleProperty total;



	ReportTable(int serial,String billno, String date,String consignor,String place,String phoneno,Double weight,int box,Double amount,Double fuelsurcharge,Double tbamount,Double tax,Double total) {
		this.serial = new SimpleIntegerProperty(serial);
		this.billno = new SimpleStringProperty(billno);
		this.date = new SimpleStringProperty(date);
		this.consignor = new SimpleStringProperty(consignor);
		this.place = new SimpleStringProperty(place);
		this.phoneno = new SimpleStringProperty(phoneno);
		this.weight = new SimpleDoubleProperty(weight);
		this.box= new SimpleIntegerProperty(box);
		this.amount = new SimpleDoubleProperty(amount);
		this.fuelsurcharge= new SimpleDoubleProperty(fuelsurcharge);
		this.tbamount = new SimpleDoubleProperty(tbamount);
		this.tax = new SimpleDoubleProperty(tax);
		this.total = new SimpleDoubleProperty(total);
	}
	
	
public IntegerProperty serialProperty(){
	return serial;
	
}
public StringProperty billnoProperty(){
	return billno;
}
public StringProperty dateProperty(){
	return date;
}
public StringProperty consignorProperty(){
	return consignor;
}
public StringProperty placeProperty(){
	return place;
}
public StringProperty phonenoProperty(){
	return phoneno;
}

public DoubleProperty weightProperty(){
	return weight;
}
	public IntegerProperty boxProperty(){
		return box;
}

public DoubleProperty amountProperty(){
	return amount;

}
public DoubleProperty fuelsurchargeProperty(){
	return fuelsurcharge;
}
public DoubleProperty tbamountProperty(){
	return tbamount;

}
public DoubleProperty taxProperty(){
	return tax;

}
public DoubleProperty totalProperty(){
	return total;
}
}
