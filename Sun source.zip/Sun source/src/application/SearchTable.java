package application;

import javafx.beans.property.DoubleProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
//import javafx.beans.property.StringProperty
import javafx.beans.property.StringProperty;

public class SearchTable
{
	public IntegerProperty pojosno;
	 public StringProperty pojobillno;
	 public StringProperty pojodate;
	 public StringProperty pojoclientcname;
	 public StringProperty pojoaddress;
	 public StringProperty pojodestination;
	 public StringProperty pojophnno;
	 public DoubleProperty pojoweight;
	 public IntegerProperty pojobox;
	 public DoubleProperty pojobasevalue;
	 public DoubleProperty pojofuel;
	 public DoubleProperty pojotax;
	 public DoubleProperty pojototal;
	 SearchTable(int pojosno,String pojobillno, String pojodate,String pojoclientcname,String pojoaddress,String pojodestination,String pojophnno,Double pojoweight,Integer pojobox,Double pojobasevalue,Double pojofuel,Double pojotax,Double pojototal) {
		    this.pojosno=new SimpleIntegerProperty(pojosno);
			this.pojobillno=new SimpleStringProperty(pojobillno);
			this.pojodate=new SimpleStringProperty(pojodate);
			this.pojoclientcname=new SimpleStringProperty(pojoclientcname);
			this.pojoaddress=new SimpleStringProperty (pojoaddress);
			this.pojodestination=new SimpleStringProperty (pojodestination);
			this.pojophnno=new SimpleStringProperty(pojophnno);
			this.pojoweight=new SimpleDoubleProperty (pojoweight);
			this.pojobox=new SimpleIntegerProperty (pojobox);
			this.pojobasevalue=new SimpleDoubleProperty (pojobasevalue);
			this.pojofuel=new SimpleDoubleProperty (pojofuel);
			this.pojotax=new SimpleDoubleProperty (pojotax);
			this.pojototal=new SimpleDoubleProperty (pojototal);
 }
	 public IntegerProperty pojosnoProperty()
		{
			return pojosno;
		}
	 public StringProperty pojobillnoProperty()
		{
			return pojobillno;
		}
	 public StringProperty pojodateProperty()
		{
			return pojodate;
		}
	 public StringProperty pojoclientcnameProperty()
	 	{
		return pojoclientcname;
	 	}
	 public StringProperty pojoaddressProperty()
		{
			return pojoaddress;
		}
	 
	 public StringProperty pojodestinationProperty()
	 {
		 return pojodestination;
	 }

	 public StringProperty pojophnnoProperty()
	 {
		 return pojophnno;
	 }
	 public DoubleProperty pojoweightProperty()
	 {
		 return pojoweight;
	 }

	 public IntegerProperty pojoboxProperty()
		{
			return pojobox;
		}
	 public DoubleProperty pojobasevalueProperty()
	 {
		 return pojobasevalue;
	 }
	 public DoubleProperty pojofuelProperty()
	 {
		 return pojofuel;
	 }
	 public DoubleProperty pojotaxProperty()
	 {
		 return pojotax;
	 }
	 public DoubleProperty pojototalProperty()
	 {
		 return pojototal;
	 }

}


