package application;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.StringTokenizer;

import javax.swing.JOptionPane;
import javax.swing.JPanel;

import com.sun.javafx.scene.control.SelectedCellsMap;

import javafx.application.Platform;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TablePosition;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
//import net.sf.jasperreports.engine.JRException;
//import net.sf.jasperreports.engine.JRResultSetDataSource;
//import net.sf.jasperreports.engine.JasperCompileManager;
//import net.sf.jasperreports.engine.JasperFillManager;
//import net.sf.jasperreports.engine.JasperPrint;
//import net.sf.jasperreports.engine.JasperReport;
//import net.sf.jasperreports.engine.design.JasperDesign;
//import net.sf.jasperreports.engine.xml.JRXmlLoader;
//import net.sf.jasperreports.view.JasperViewer;  
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRResultSetDataSource;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.view.JasperViewer;

public class Town implements Initializable{ 
	public TextField tname,tcode;
	Connection connect;
	PreparedStatement pstmt,pstmt1,pst;
	ResultSet rs, rs1, rs2;
	Statement stmt, stmt1;
	public TableView towntable;
	 public TableColumn<Towntable,String>townname,towncode;
	 ObservableList<Towntable> list2 = FXCollections.observableArrayList();


	public void initialize(URL arg0, ResourceBundle arg1)
	
	{
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/sun", "root", "root");
			pstmt = connect.prepareStatement("select * from townname");
			rs2 = pstmt.executeQuery();
			while (rs2.next()) {
				list2.add(new Towntable(rs2.getString("Name"),
						rs2.getString("Code")));
			}
			
			townname.setCellValueFactory(new PropertyValueFactory<Towntable, String>("pojotname"));
			towncode.setCellValueFactory(new PropertyValueFactory<Towntable, String>("pojotcode"));
			towntable.setItems(list2);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	public void add() throws SQLException
	{
			pstmt = connect.prepareStatement( "insert into townname(Name,Code)Values(?,?)");
			pstmt.setString(1, tname.getText());
			pstmt.setString(2, tcode.getText());
			int rs = pstmt.executeUpdate();
			clear1();
			clear();
			initialize(null,null);
}
	public void view() throws IOException, ClassNotFoundException, SQLException, JRException
	{
		Class.forName("com.mysql.jdbc.Driver");
		connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/sun", "root", "root");
		pstmt=connect.prepareStatement("select * from townname");
		rs = pstmt.executeQuery();
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("ReportTitle", "PDF JasperReport");
			
		JRResultSetDataSource jas=new JRResultSetDataSource(rs);
		
		//System.out.println("jasper" + jas);
		JasperPrint jasperPrint = JasperFillManager.fillReport("C:/jasper/codelist.jasper", parameters,jas);
		JasperViewer viewer = new JasperViewer(jasperPrint);
		viewer.setTitle("Time Reports");
		viewer.viewReport(jasperPrint, false);
	}
	public void clear()
	{
			tname.clear();
			tcode.clear();
		
	}
	public void clear1()
	{
		for (int i=0;i< towntable.getItems().size();i++)
		{
			towntable.getItems().clear();
		}
	}
	public void update() throws SQLException
	{
		pstmt1 = connect.prepareStatement("update townname set Code=? where Name=?");
		pstmt1.setString(1, tcode.getText());
		pstmt1.setString(2, tname.getText());
		pstmt1.executeUpdate();
		clear();
		clear1();
		initialize(null,null);
		}
	public void delete()
	{
		try
		{
			Alert alert = new Alert(AlertType.CONFIRMATION);
			alert.setTitle("Confirmation Dialog");
			alert.setHeaderText("Do You Want To Delete");
			
			Optional<ButtonType> result = alert.showAndWait();
			if (result.get() == ButtonType.OK){
				pst=connect.prepareStatement("delete from townname where Code=?");
				pst.setString(1, tcode.getText());
				pst.executeUpdate();
				
				   Alert alert1=new Alert(AlertType.INFORMATION);
					alert1.setContentText("Deleted Successfully");
		            alert1.show();
			}
	}
		catch(Exception e)
		{
		e.printStackTrace();
		}
		clear();
		clear1();
		initialize(null,null);
		
}
	
	public void click()
	{
		Towntable retrive=(Towntable) towntable.getSelectionModel().getSelectedItem();
		tname.setText(retrive.pojotname.get());
		tcode.setText(retrive.pojotcode.get());
	}

}