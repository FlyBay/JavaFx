package application;
import javafx.beans.InvalidationListener;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;


public class customertable {
	public SimpleStringProperty pojocode;
	public SimpleStringProperty pojoname;
	public SimpleStringProperty pojoaddress;
	public SimpleStringProperty pojoplace;
	public SimpleStringProperty pojomail;
	public SimpleStringProperty pojophnno;
	public SimpleDoubleProperty pojocgst;
	public SimpleDoubleProperty pojosgst;
	public SimpleStringProperty pojofax;
	public SimpleStringProperty pojogst;
	
	public customertable( String pojocode, String pojoname,String pojoaddress,String pojoplace,String pojomail,String pojophnno,Double pojocgst,Double pojosgst,String pojofax,String pojogst) 
	{
		this.pojocode = new SimpleStringProperty(pojocode);
		this.pojoname =new SimpleStringProperty(pojoname);
		this.pojoaddress=new SimpleStringProperty(pojoaddress);
        this.pojoplace=new SimpleStringProperty(pojoplace);
        this.pojomail=new SimpleStringProperty(pojomail);
        this.pojophnno=new SimpleStringProperty(pojophnno);
        this.pojocgst=new SimpleDoubleProperty(pojocgst);
 		this.pojosgst = new SimpleDoubleProperty(pojosgst);
 		this.pojofax=new SimpleStringProperty(pojofax);
 		this.pojogst=new SimpleStringProperty(pojogst);
	}
	public StringProperty pojocodeProperty(){
		return pojocode;
	}
		public StringProperty pojonameProperty() {
			return pojoname;
			
		}
		public StringProperty pojoaddressProperty() {
			return pojoaddress;
		}
		
		public StringProperty pojoplaceProperty() {
			return pojoplace;
		}
		public StringProperty pojomailProperty() {
			return pojomail;
		}
		public StringProperty pojophnnoProperty() {
			return pojophnno;
		}
		public DoubleProperty pojocgstProperty() {
			return pojocgst;
		}
		public DoubleProperty pojosgstProperty() {
			return pojosgst;
		}
		public StringProperty pojofaxProperty() {
			return pojofax;
		}
		public StringProperty pojogstProperty() {
			return pojogst;
		}
}
