package application;

import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

import com.mysql.jdbc.exceptions.jdbc4.MySQLIntegrityConstraintViolationException;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ComboBox;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.control.TextField;



public class Backup implements Initializable
{
	public TextField old,bill,name;
	PreparedStatement pstmt,pstmt1;
	ResultSet rs,rs1;
	Connection con;
	static String number;
	Integer s;
	public void modify() throws SQLException 
	{
		s=Integer.parseInt(bill.getText());
		pstmt=con.prepareStatement("update airwaybills set AirwayBillNo=? where AirwayBillNo=? and Consignor=?");
		
		pstmt.setInt(1,s);
		pstmt.setString(2, old.getText());
		pstmt.setString(3, name.getText());
		int modify = pstmt.executeUpdate();
		
		
		pstmt=con.prepareStatement("update temp_airwaybills set AirwayBillNo=? where AirwayBillNo=? and Consignor=?");
		pstmt.setInt(1,s);
		pstmt.setString(2, old.getText());
		pstmt.setString(3, name.getText());
		int modi = pstmt.executeUpdate();
	
		old.clear();
		bill.clear();
		name.clear();
		
		
		Alert alert1=new Alert(AlertType.INFORMATION);
		alert1.setContentText("AirWay Bill Number Successfully Updated");
        alert1.show();
	//	System.out.println(old.getText());
		//System.out.println(bill.getText());
		
	}
	
	public void initialize(URL arg0, ResourceBundle arg1) {
	
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/sun","root","root");	
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		name.setEditable(true);
		
		
		}
	
	public void key(KeyEvent event) throws SQLException, ClassNotFoundException 
	 {	
		
	  if (event.getCode()==KeyCode.TAB)
	  {
		  pstmt = con.prepareStatement("select AirwayBillNo from airwaybills");
		  ResultSet rs = pstmt.executeQuery();
		  while (rs.next())
		  {
			// System.out.println(old.getText());
			 number = rs.getString("AirWayBillNo");
			 //System.out.println(number);
		  
	 			if(old.getText().equals(number))	
	 			{
	 				Alert alt = new Alert(AlertType.INFORMATION);
	 				alt.setTitle("Alert Message");
	 				alt.setContentText("This Is A Valid AirWay ");
	 				alt.showAndWait();
	 			}	
	 	}
		  
		  pstmt1=con.prepareStatement("select Consignor from airwaybills where AirwayBillNo=?");
		  pstmt1.setString(1,old.getText());
		  ResultSet rs11 = pstmt1.executeQuery();
		  while (rs11.next())
		  {
			 name.setText(rs11.getString("Consignor"));
		  } 
	  }
	  }
		  
		  
	 }

