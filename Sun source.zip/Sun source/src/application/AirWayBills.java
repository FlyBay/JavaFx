package application;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.StringTokenizer;

import javafx.application.Platform;
import javafx.beans.property.DoubleProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRResultSetDataSource;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.view.JasperViewer;

public class AirWayBills implements Initializable {
	public TextField airwaybillno,phoneno,invoiceno,weight,box,amount,fuelsurcharge,cgst,sgst,grandtotal,client;
	public TextArea consignoraddr;
	public ComboBox cname,townname;
	public TableView table;
	public TableColumn<AWBTable, String> tconsignor,tplace,tbillno,tdate,tphno;
	public TableColumn<AWBTable, Double> tamount,ttax,tgtotal,tfuel,tweight;
	public TableColumn<AWBTable, Integer> tsno,tbox;
	public DatePicker date;
	Connection con;
	 ObservableList<Object> list2 = FXCollections.observableArrayList();
	 ObservableList<Object> list3 = FXCollections.observableArrayList();
		public ObservableList<String> list,placelist,placelist2;
	PreparedStatement pstmt,pstmt1,pstmt2,pstmt3,pstmt4,pstmt5,pstmt6,pst,ps;
	Statement stmt,stmt2,stmt6;
	ResultSet rs,rs1,rs2,rs3,rs4,rs5,rs7,rs8,rs6,rs9,rs18,rs20;
	static int tableserial=1,serial=1;
	static String cltName=null;
	Integer s;
	Double tax=0.00,ctax=0.00,stax=0.00,tottax=0.00,amt=0.00,fsc=0.00,totamt=0.00,grdtot=0.00,perKg=0.00,wgt=0.00,amtCalc=0.00,cttax=0.00,sttax=0.00,gtotal=0.00,sur=0.00,base=0.00,vamount=0.00,tvamount=0.00,fscv=0.00,FSC=0.00;
	private static final String[] tens = { "", " TEN", " TWENTY", " THIRTY", " FORTY", " FIFTY", " SIXTY", " SEVENTY",
			" EIGHT", " NINETY" };
	private static final String[] units = { "", " ONE", " TWO", " THREE", " FOUR", " FIVE", " SIX", " SEVEN", " EIGHT",
			" NINE", " TEN", " ELEVEN", " TWELVE", " THIRTEEN", " FOURTEEN", " FIFTEEN", " SIXTEEN", " SEVENTEEN",
			" EIGHTEEN", " NINETEEN" };
	
	
	
	public void add() throws SQLException 
	{
		
		LocalDate localDate = date.getValue();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		String date1 = localDate.format(formatter);
		 
		serial=serial+1;
		s=Integer.parseInt(airwaybillno.getText());
		pstmt = con.prepareStatement("insert into airwaybills(AirWayBillNo,Date,Consignor,Place,Weight,Box,ConsignorAddress,PhoneNo,Amount,FuelSurCharge,CGST,SGST,TotalAmount,Tax,CTax,STax,S_No,Code)values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
		pstmt.setInt(1,s);
		pstmt.setString(2, date1);
		pstmt.setString(3, cname.getEditor().getText());
		pstmt.setString(4, townname.getEditor().getText());
		pstmt.setString(5, weight.getText());
		pstmt.setString(6, box.getText());
		pstmt.setString(7, consignoraddr.getText());
		pstmt.setString(8, phoneno.getText());
		pstmt.setString(9, amount.getText());
		pstmt.setDouble(10, fscv);
		pstmt.setString(11, cgst.getText());
		pstmt.setString(12, sgst.getText());
		pstmt.setDouble(13, grdtot);
		pstmt.setDouble(14, tax);
		pstmt.setDouble(15, cttax);
		pstmt.setDouble(16, sttax);
		pstmt.setInt(17, serial);
		pstmt.setString(18, client.getText());
		int jega=pstmt.executeUpdate();
				
		pstmt = con.prepareStatement("insert into temp_airwaybills(AirWayBillNo,Date,Consignor,Place,Weight,Box,ConsignorAddress,PhoneNo,Amount,FuelSurCharge,CGST,SGST,TotalAmount,CTax,STax,Tax,S_No,Code)values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
		pstmt.setInt(1,s);
		pstmt.setString(2, date1);
		pstmt.setString(3, cname.getEditor().getText());
		pstmt.setString(4, townname.getEditor().getText());
		pstmt.setString(5, weight.getText());
		pstmt.setString(6, box.getText());
		pstmt.setString(7, consignoraddr.getText());
		pstmt.setString(8, phoneno.getText());
		pstmt.setString(9, amount.getText());
		pstmt.setDouble(10, fscv);
		pstmt.setString(11, cgst.getText());
		pstmt.setString(12, sgst.getText());
		pstmt.setDouble(13, grdtot);
		pstmt.setDouble(14, cttax);
		pstmt.setDouble(15, sttax);
		pstmt.setDouble(16, tax);
		pstmt.setInt(17, serial);
		pstmt.setString(18, client.getText());
		int vishnu=pstmt.executeUpdate();
		
		pstmt6 = con.prepareStatement("update airwaybills set Vamount=? where AirWayBillNo=?");
		pstmt6.setDouble(1, vamount);
		pstmt6.setString(2, airwaybillno.getText());
		int result2 = pstmt6.executeUpdate();
		
		
		pstmt4=con.prepareStatement("select GSTNo from customerdetails where Name=?");
		pstmt4.setString(1, cname.getEditor().getText());
		rs18=pstmt4.executeQuery();
		while(rs18.next())
		{
		String n=(rs18.getString("GSTNo"));
		pstmt3=con.prepareStatement("update airwaybills set Gstno=? where Consignor=?");
		pstmt3.setString(1, n);
		pstmt3.setString(2, cname.getEditor().getText());
		int bhai = pstmt3.executeUpdate();
		}
		
		clear1();
		initialize(null,null);
		cname.getSelectionModel().clearSelection();
		cname.getEditor().clear();
		airwaybillno.clear();
		weight.clear();		
		amount.clear();
		box.clear();
		consignoraddr.clear();
		phoneno.clear();
		cgst.clear();
		sgst.clear();
		fuelsurcharge.clear();
		date.setValue(null);
		grandtotal.clear();
		client.clear();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		tableserial=1;serial=0;
		//cname.getItems().clear();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/sun","root","root");	
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();	
		}		   
		try {					
		pstmt5 = con.prepareStatement("select * from customerdetails");
		 list = FXCollections.observableArrayList();
		 placelist = FXCollections.observableArrayList();
			
		    rs1=pstmt5.executeQuery();
			while (rs1.next()) {
				list.add(rs1.getString("Name"));
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

			cname.setEditable(true);
			cname.setItems(list);
			FilteredList<String> consfilter = new FilteredList<String>(list, p -> true);
			cname.getEditor().textProperty().addListener((obs, oldValue, newValue) -> {
				final TextField conseditor = cname.getEditor();
				final Object consselected = cname.getSelectionModel().getSelectedItem();
				Platform.runLater(() -> {
					if (consselected == null || !consselected.equals(conseditor.getText())) {
						consfilter.setPredicate(item -> {
							if (item.toUpperCase().startsWith(newValue.toUpperCase())) {
								return true;
							} else {
								return false;
							}
						});
					}
				});
			});
			cname.setItems(consfilter);
			new AutoCompleteComboBoxListener<>(cname);
			
			townname.setEditable(true);
			
			
			 try {

				 pstmt1 = con.prepareStatement("select * from temp_airwaybills");
				 rs4= pstmt1.executeQuery();
					while (rs4.next()) 
					{
						list2.add(new AWBTable(tableserial, rs4.getString("AirwayBillNo"), rs4.getString("PhoneNo"),
								rs4.getString("Consignor"),rs4.getString("Date"),rs4.getString("Place"),rs4.getDouble("Weight"),rs4.getString("ConsignorAddress"),rs4.getInt("Box"),rs4.getDouble("Amount"),rs4.getDouble("CGST"),rs4.getDouble("SGST"),rs4.getDouble("FuelSurcharge"),rs4.getDouble("Tax"),rs4.getDouble("TotalAmount")));
						tableserial++;
					}
					tsno.setCellValueFactory(new PropertyValueFactory<AWBTable, Integer>("serial"));
					tbillno.setCellValueFactory(new PropertyValueFactory<AWBTable, String>("billno"));
					tphno.setCellValueFactory(new PropertyValueFactory<AWBTable, String>("phoneno"));
					tconsignor.setCellValueFactory(new PropertyValueFactory<AWBTable, String>("consignor"));
					tdate.setCellValueFactory(new PropertyValueFactory<AWBTable, String>("date"));
				    tplace.setCellValueFactory(new PropertyValueFactory<AWBTable, String>("place"));
					tweight.setCellValueFactory(new PropertyValueFactory<AWBTable, Double>("weight"));
					tbox.setCellValueFactory(new PropertyValueFactory<AWBTable, Integer>("box"));
					tamount.setCellValueFactory(new PropertyValueFactory<AWBTable, Double>("amount"));
					tfuel.setCellValueFactory(new PropertyValueFactory<AWBTable, Double>("fuelsurcharge"));
					ttax.setCellValueFactory(new PropertyValueFactory<AWBTable, Double>("tax"));
					tgtotal.setCellValueFactory(new PropertyValueFactory<AWBTable, Double>("grandtotal"));
					table.setItems(list2);
				
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}		 				 					 			 
	}
	public void selectconsignor() throws SQLException {
		
		pstmt2= con.prepareStatement("select * from customerdetails where Name=?");
		pstmt2.setString(1, cname.getEditor().getText());
		rs5=pstmt2.executeQuery();
		/*------Retrieving all details  when id is given start------*/
		
		while(rs5.next()) 
		{
			client/* fxml Id name*/.setText(rs5.getString("Code"/*Sql Field name*/));
			consignoraddr.setText(rs5.getString("Address"));
			phoneno.setText(rs5.getString("PhoneNo"));			
		}
		/*------Retrieving all details  when id is given End------*/				
		pstmt4= con.prepareStatement("select distinct TownName from tariffentry where ClientName=?");
		pstmt4.setString(1, cname.getEditor().getText());
		placelist2=FXCollections.observableArrayList();
		rs3=pstmt4.executeQuery();			
		while (rs3.next()) 
		{
			placelist2.add(rs3.getString("TownName"));			
		}
	    townname.setEditable(true);
		townname.setItems(placelist2);
		new AutoCompleteComboBoxListener<>(townname);		
	}
	public void selectplace() throws SQLException 
	{
		pstmt3= con.prepareStatement("select * from tariffentry where ClientName=? and TownName=?");
		pstmt3.setString(1, cname.getEditor().getText());
		pstmt3.setString(2, townname.getEditor().getText());
		rs7=pstmt3.executeQuery();
		while(rs7.next()) 
		{
			perKg=rs7.getDouble("perKg");
			wgt=(Double.valueOf(weight.getText()));
			amtCalc=perKg*wgt;
			amount.setText(Double.toString(amtCalc));
			//System.out.println(amtCalc);
		}
		pstmt=con.prepareStatement("select Fuel from tariffentry where ClientName=? and TownName=?");
		pstmt.setString(1, cname.getEditor().getText());
		pstmt.setString(2, townname.getEditor().getText());
		rs20=pstmt3.executeQuery();
		while(rs20.next())
		{
			FSC = (rs20.getDouble("Fuel"));
		}
		 pstmt=con.prepareStatement("select * from customerdetails where Name=? ");
		 pstmt.setString(1, cname.getEditor().getText());
		 rs9=pstmt.executeQuery();
		 while(rs9.next())
			{
			 
			 
			 ctax=(rs9.getDouble("CGST"));
			 
			 stax=(rs9.getDouble("SGST"));
			 
			 tottax=ctax+stax;
			
			 
			 amt=(double)Math.round((amtCalc*100)/100);
			 
			 //System.out.println("Base" +   amt);
			 
			 fscv=(double)Math.round(( amt*(FSC/100) )*100)/100; 
		 	 System.out.println(fscv);
			 vamount=(double)Math.round((fscv+amt)*100)/100;
			 totamt=amt+fscv;
			 
			 tax=(double)Math.round((totamt*(tottax/100)) *100)/100;
			 
			 cttax=(double)Math.round((totamt*(ctax/100)) *100)/100;
			 
			 sttax=(double)Math.round((totamt*(stax/100)) *100)/100;
			 
			 grdtot=(double)Math.round((totamt+cttax+sttax)*100)/100;
			 
			 cgst.setText(Double.toString(cttax));
			 
			 sgst.setText(Double.toString(sttax));
			 
			 fuelsurcharge.setText(Double.toString(fscv));
			 
			 grandtotal.setText(Double.toString(grdtot));			 
			} 
	}
	/*-----Fxml id clearance Start-----*/
	public void clear() throws SQLException 
	{
		clear1();
		initialize(null,null);
		
		airwaybillno.clear();
		cname.getSelectionModel().clearSelection();
		cname.getEditor().clear();
		townname.getSelectionModel().clearSelection();
		townname.getEditor().clear();
		consignoraddr.clear();
		phoneno.clear();
		weight.clear();
		amount.clear();
		cgst.clear();
		sgst.clear();
		date.setValue(null);
		box.clear();
		fuelsurcharge.clear();
		grandtotal.clear();
		client.clear();
		tax=0.00;tax=0.00;ctax=0.00;stax=0.00;tottax=0.00;amt=0.00;fsc=0.00;totamt=0.00;grdtot=0.00;perKg=0.00;wgt=0.00;amtCalc=0.00;fscv=0.00;	
	}
	/*-----Fxml id clearance End-----*/
	public void clear1() 
	 {
		   for (int i= 0 ;i < table.getItems().size(); i++) 
		   {
			table.getItems().clear();
			}
		   tableserial=1;
	 }
	 public void delete() throws SQLException
	 {
		 try
		 {
			Alert alert = new Alert(AlertType.CONFIRMATION);
			alert.setTitle("Confirmation Dialog");
			alert.setHeaderText("Do You Want To Delete");
			
			Optional<ButtonType> result = alert.showAndWait();
			if (result.get() == ButtonType.OK)
			{
				pst=con.prepareStatement("delete from temp_airwaybills where AirwayBillNo=?");
				pst.setString(1, airwaybillno.getText());
				pst.executeUpdate();
				
				ps=con.prepareStatement("delete from airwaybills where AirwayBillNo=?");
				ps.setString(1, airwaybillno.getText());
				ps.executeUpdate();
				
				   Alert alert1=new Alert(AlertType.INFORMATION);
					alert1.setContentText("Deleted Successfully");
		            alert1.show();
			}
		 }
		catch(Exception e)
		{
		e.printStackTrace();
		}
	 	airwaybillno.clear();
		cname.getEditor().clear();
		townname.getEditor().clear();
		consignoraddr.clear();
		phoneno.clear();
		weight.clear();
		amount.clear();
		cgst.clear();
		sgst.clear();
		date.getEditor().clear();
		box.clear();
		fuelsurcharge.clear();
		grandtotal.clear();
		
		clear1();
		initialize(null,null);
		
	 }
	 	
	 public void click()
	 {
		 AWBTable retrive=(AWBTable) table.getSelectionModel().getSelectedItem();
		 airwaybillno.setText(retrive.billno.get());
		 cname.getEditor().setText(retrive.consignor.get());
		 townname.getEditor().setText(retrive.place.get());
		 consignoraddr.setText(retrive.address.get());
		 phoneno.setText(retrive.phoneno.get());
		 weight.setText(Double.toString(retrive.weight.get()));
		 amount.setText(Double.toString(retrive.amount.get()));
		 cgst.setText(Double.toString(retrive.cgst.get()));
		 sgst.setText(Double.toString(retrive.sgst.get()));
		 date.getEditor().setText(retrive.date.get());
		 box.setText(Integer.toString(retrive.box.get()));
		 fuelsurcharge.setText(Double.toString(retrive.fuelsurcharge.get()));
		 grandtotal.setText(Double.toString(retrive.grandtotal.get()));	 
	 }
	 
	 public void key(KeyEvent event) throws SQLException 
	 {	
	  if (event.getCode()==KeyCode.TAB)
	  {
	 		 PreparedStatement prep = con.prepareStatement("select AirwayBillNo from airwaybills");
	 		 ResultSet st=prep.executeQuery();
	 		 while (st.next())
	 		 {
	 			String number=(st.getString("AirwayBillNo"));
	 			if(airwaybillno.getText().equals(number))
	 			{
	 				Alert alt = new Alert(AlertType.INFORMATION);
	 				alt.setTitle("Alert Message");
	 				alt.setContentText("This AirwayBillNo Number Already Exist");
	 				alt.showAndWait();
	 			break;
	   }
	  }	 
	  }
	}
	 public void modify() throws SQLException
	 {
		LocalDate localDate = date.getValue();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		String date1 = localDate.format(formatter);
		pstmt=con.prepareStatement("update airwaybills set Date=?,Place=?,Weight=?,Box=?,Amount=?,FuelSurCharge=?,CGST=?,SGST=?,TotalAmount=?,Consignor=? where AirwayBillNo=?");
		pstmt.setString(1, date1);
		pstmt.setString(2, townname.getEditor().getText());
		pstmt.setString(3, weight.getText());
		pstmt.setString(4, box.getText());
		pstmt.setString(5, amount.getText());
		pstmt.setString(6, fuelsurcharge.getText());
		pstmt.setString(7, cgst.getText());
		pstmt.setString(8, sgst.getText());
		pstmt.setString(9, grandtotal.getText());
		pstmt.setString(10, cname.getEditor().getText());
		pstmt.setString(11, airwaybillno.getText());
		int set = pstmt.executeUpdate();
		pstmt1=con.prepareStatement("update temp_airwaybills set Date=?,Place=?,Weight=?,Box=?,Amount=?,FuelSurCharge=?,CGST=?,SGST=?,TotalAmount=?,Consignor=? where AirwayBillNo=?");
		pstmt1.setString(1, date1);
		pstmt1.setString(2, townname.getEditor().getText());
		pstmt1.setString(3, weight.getText());
		pstmt1.setString(4, box.getText());
		pstmt1.setString(5, amount.getText());
		pstmt1.setString(6, fuelsurcharge.getText());
		pstmt1.setString(7, cgst.getText());
		pstmt1.setString(8, sgst.getText());
		pstmt1.setString(9, grandtotal.getText());
		pstmt1.setString(10, cname.getEditor().getText());
		pstmt1.setString(11, airwaybillno.getText());
		int sett = pstmt1.executeUpdate();
		pstmt6 = con.prepareStatement("update airwaybills set Vamount=? where AirWayBillNo=?");
		pstmt6.setDouble(1, vamount);
		pstmt6.setString(2, airwaybillno.getText());
		int result2 = pstmt6.executeUpdate();
		airwaybillno.clear();
		cname.getSelectionModel().clearSelection();
		cname.getEditor().clear();
		townname.getSelectionModel().clearSelection();
		townname.getEditor().clear();
		consignoraddr.clear();
		phoneno.clear();
		weight.clear();
		amount.clear();
		cgst.clear();
		sgst.clear();
		date.setValue(null);
		box.clear();
		fuelsurcharge.clear();
		grandtotal.clear();
		client.clear();
		clear1();
		initialize(null,null);	
	 }	 
}