package application;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.StringTokenizer;

import javax.mail.internet.AddressException;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.SingleSelectionModel;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;
import javafx.util.Callback;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRResultSetDataSource;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.export.JRPdfExporter;
import net.sf.jasperreports.engine.export.JRXlsExporter;
import net.sf.jasperreports.engine.export.JRXlsExporterParameter;
import net.sf.jasperreports.view.JasperViewer;

public class Report implements Initializable {
public	ComboBox cname;
public	DatePicker from,to,ivdate;
public	TableView table;
public TextField invoice,code;
public	TableColumn<ReportTable, Integer>tsno,tboxes;
public	TableColumn<ReportTable, String>tbillno,tconsignor,tplace,tphoneno,tdate;
public TableColumn<ReportTable, Double>tweight,tamount,tfuelcost,ttax,ttotal,tbamount;
public Connection con,connect;
static double tot=0.00,tox=0.00,conversion=0.00,roundoff=0.00,sheen=0.00,ctax=0.00,stax=0.00,finaltotal=0.00;
static int word,conversionfinal;
public	PreparedStatement sltname,sltbillno,sltbill,viewbillno,viewbwdate,viewdate,pstmt,pstmt1,pstmt2,vishnu,pstmt9,pstmtl,pcover;
public ObservableList<String> Namelist,BillNolist,BillList;
ObservableList tablelist = FXCollections.observableArrayList();
ObservableList tabledtlist = FXCollections.observableArrayList();
ResultSet rsname,rsbillno,rsbill,rsviewbno,rsviewbwdt,rsviewdt,rs,rs1,rs2,vis,pudhu,ajith,rsl,insert;
int tableserial=1;											
Statement stmt, stmt1,stmt2;
List<JasperPrint> list;
private static final String[] tens = { "", " TEN", " TWENTY", " THIRTY", " FOURTY", " FIFTY", " SIXTY", " SEVENTY","EIGHTY","NINETY"};
private static final String[] units = { "", " ONE", " TWO", " THREE", " FOUR", " FIVE", " SIX", " SEVEN", " EIGHT",
		" NINE", " TEN", " ELEVEN", " TWELVE", " THIRTEEN", " FOURTEEN", " FIFTEEN", " SIXTEEN", " SEVENTEEN",
		" EIGHTEEN", " NINETEEN" };

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		try {
		Class.forName("com.mysql.jdbc.Driver");
		con=DriverManager.getConnection("jdbc:mysql://localhost:3306/sun","root","root");	
		
		sltname = con.prepareStatement("select distinct Consignor from airwaybills");
		Namelist = FXCollections.observableArrayList();
		rsname=sltname.executeQuery();
	    
		while (rsname.next()) 
		{
			Namelist.add(rsname.getString("Consignor"));
		}
		
		cname.setEditable(true);
		cname.setItems(Namelist);

		new AutoCompleteComboBoxListener<>(cname);
		
		    
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (NumberFormatException e)
		{
			// TODO Auto-generated catch block
						e.printStackTrace();
		}
		
		
	}
		
			
	public void view() throws SQLException, ClassNotFoundException {
		clear1();
		
		if(to.getEditor().getText().isEmpty())
			
		{
	
		LocalDate localDate = from.getValue();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		String date = localDate.format(formatter);
		
		viewbillno=con.prepareStatement("select * from airwaybills where Consignor=? and Date=?");
		viewbillno.setString(1, cname.getEditor().getText());
		viewbillno.setString(2, date);
		rsviewbno=viewbillno.executeQuery();
		
		while(rsviewbno.next()) {
			tablelist.add(new ReportTable(tableserial, rsviewbno.getString("AirwayBillNo"), rsviewbno.getString("Date"),
					rsviewbno.getString("Consignor"),rsviewbno.getString("Place"),rsviewbno.getString("PhoneNo"),rsviewbno.getDouble("Weight"),rsviewbno.getInt("Box"),rsviewbno.getDouble("Amount"),rsviewbno.getDouble("FuelSurcharge"),rsviewbno.getDouble("Vamount"),rsviewbno.getDouble("Tax"),rsviewbno.getDouble("TotalAmount")));
			tableserial++;
		}
		tsno.setCellValueFactory(new PropertyValueFactory<ReportTable, Integer>("serial"));
		tbillno.setCellValueFactory(new PropertyValueFactory<ReportTable, String>("billno"));
		tdate.setCellValueFactory(new PropertyValueFactory<ReportTable, String>("date"));
		tconsignor.setCellValueFactory(new PropertyValueFactory<ReportTable, String>("consignor"));
		tplace.setCellValueFactory(new PropertyValueFactory<ReportTable, String>("place"));
	    tphoneno.setCellValueFactory(new PropertyValueFactory<ReportTable, String>("phoneno"));
		tweight.setCellValueFactory(new PropertyValueFactory<ReportTable, Double>("weight"));
		tboxes.setCellValueFactory(new PropertyValueFactory<ReportTable, Integer>("box"));
		tamount.setCellValueFactory(new PropertyValueFactory<ReportTable, Double>("amount"));
		tfuelcost.setCellValueFactory(new PropertyValueFactory<ReportTable, Double>("fuelsurcharge"));
		tbamount.setCellValueFactory(new PropertyValueFactory<ReportTable, Double>("tbamount"));
		ttax.setCellValueFactory(new PropertyValueFactory<ReportTable, Double>("tax"));
		ttotal.setCellValueFactory(new PropertyValueFactory<ReportTable, Double>("total"));
		table.setItems(tablelist);
		
		total();
		tottax();
		}
		
		else
		
		{
		
		clear1();		
		LocalDate fromDate = from.getValue();
		DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		String from = fromDate.format(formatter1);
		
		LocalDate todate = to.getValue();
		DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		String to = todate.format(formatter2);
		
		//System.out.println(from);
		//System.out.println(to);
		
		
		viewdate=con.prepareStatement("select * from airwaybills where Consignor=? and Date between ? and ? and Code=?");
		viewdate.setString(1, cname.getEditor().getText());
		viewdate.setString(2, from);
		viewdate.setString(3, to);
		viewdate.setString(4, code.getText());
		rsviewdt=viewdate.executeQuery();
		
		while(rsviewdt.next()) 
		{
			tabledtlist.add(new ReportTable(tableserial, rsviewdt.getString("AirwayBillNo"), rsviewdt.getString("Date"),
	        rsviewdt.getString("Consignor"),rsviewdt.getString("Place"),rsviewdt.getString("PhoneNo"),rsviewdt.getDouble("Weight"),rsviewdt.getInt("Box"),rsviewdt.getDouble("Amount"),rsviewdt.getDouble("FuelSurcharge"),rsviewdt.getDouble("Vamount"),rsviewdt.getDouble("Tax"),rsviewdt.getDouble("TotalAmount")));
			tableserial++;
		}
		tsno.setCellValueFactory(new PropertyValueFactory<ReportTable, Integer>("serial"));
		tbillno.setCellValueFactory(new PropertyValueFactory<ReportTable, String>("billno"));
		tdate.setCellValueFactory(new PropertyValueFactory<ReportTable, String>("date"));
		tconsignor.setCellValueFactory(new PropertyValueFactory<ReportTable, String>("consignor"));
		tplace.setCellValueFactory(new PropertyValueFactory<ReportTable, String>("place"));
	    tphoneno.setCellValueFactory(new PropertyValueFactory<ReportTable, String>("phoneno"));
		tweight.setCellValueFactory(new PropertyValueFactory<ReportTable, Double>("weight"));
		tboxes.setCellValueFactory(new PropertyValueFactory<ReportTable, Integer>("box"));
		tamount.setCellValueFactory(new PropertyValueFactory<ReportTable, Double>("amount"));
		tfuelcost.setCellValueFactory(new PropertyValueFactory<ReportTable, Double>("fuelsurcharge"));
		tbamount.setCellValueFactory(new PropertyValueFactory<ReportTable, Double>("tbamount"));
		ttax.setCellValueFactory(new PropertyValueFactory<ReportTable, Double>("tax"));
		ttotal.setCellValueFactory(new PropertyValueFactory<ReportTable, Double>("total"));;
		table.setItems(tabledtlist);
		
		
		vishnu=con.prepareStatement("update airwaybills set InvoiceNo=? where consignor=? and Date between ? and ?");
		vishnu.setString(1, invoice.getText());
		vishnu.setString(2, cname.getEditor().getText());
		vishnu.setString(3, from);
		vishnu.setString(4, to);
		int jegav=vishnu.executeUpdate();
		
		
		total();
		tottax();
		initialize(null,null);
		
		
		
		/*pstmt=con.prepareStatement("SELECT DATE_FORMAT(Date, \"%d-%m-%Y\") as Data FROM airwaybills where Consignor=? and Date between ? and ?");
		pstmt.setString(1, cname.getEditor().getText());
		pstmt.setString(2,from);
		pstmt.setString(3,to);
		ResultSet result = pstmt.executeQuery();
		while (result.next())
		{
			String Vishnu= (result.getString("Data"));
			System.out.println(Vishnu);
		}
		*/
		
		}
	}
		
	
	
    
public void total() throws SQLException, ClassNotFoundException
{
	Class.forName("com.mysql.jdbc.Driver");
	con=DriverManager.getConnection("jdbc:mysql://localhost:3306/sun","root","root");
	
	
	if(to.getEditor().getText().isEmpty())
	{
		LocalDate localDate = from.getValue();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		String date = localDate.format(formatter);
		
		rsviewbno.beforeFirst();
		while(rsviewbno.next()) 
		{
			tot+=(Double.parseDouble(rsviewbno.getString("TotalAmount")));
			//System.out.println(tot);	
		}
		
		pstmt1=con.prepareStatement("update airwaybills set GrandTotal=? where Consignor=? and Date=? and Code=?");
		pstmt1.setDouble(1,tot);
		pstmt1.setString(2, cname.getEditor().getText());
		pstmt1.setString(3, date);
		pstmt1.setString(4, code.getText());
		pstmt1.executeUpdate();
		
		conversion = Math.round(tot);
		roundoff=(double)Math.round((conversion-tot)*100)/100;
		
		Double myDouble = Double.valueOf(conversion);
		double dbl = myDouble.doubleValue();
		conversionfinal = (int) dbl;
		
		System.out.println(conversionfinal);
			
		//int word = Integer.valueOf(conversion.intValue());
		
		word = Double.valueOf(conversion).intValue();
		String amountword = convert(word);
		System.out.println(word);
		System.out.println(amountword);
		
		pstmt9=con.prepareStatement("update airwaybills set Words=? where Consignor=? and Date=?");
		pstmt9.setString(1,amountword);
		pstmt9.setString(2, cname.getEditor().getText());
		pstmt9.setString(3, date);
		pstmt9.executeUpdate();
		
		
		
		tot=0.00;
		dbl=0;
		

	}
	else
	{
		LocalDate fromDate = from.getValue();
		DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		String from = fromDate.format(formatter1);
		
		LocalDate todate = to.getValue();
		DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		String to = todate.format(formatter2);
		
		PreparedStatement different = con.prepareStatement("select * from airwaybills where Consignor=? and Date between ? and ? and Code=?");
		different.setString(1, cname.getEditor().getText());
		different.setString(2,from);
		different.setString(3,to);
		different.setString(4, code.getText());
		ResultSet sheena = different.executeQuery();
		
		while(sheena.next())
		{
			System.out.println(sheena.getString("Vamount"));
			sheen+=(Double.parseDouble(sheena.getString("Vamount")));
			
		}
		
		ctax=(double)Math.round(((sheen*9)/100)  *100)/100;
		
		stax=(double)Math.round(((sheen*9)/100)  *100)/100;
		
		System.out.println("Total"+"    "+sheen);
		System.out.println("Ctax"+"     "+ctax);
		System.out.println("STax"+"     "+stax);
		
		finaltotal=sheen+ctax+stax;
		System.out.println("FinalTotal"+"    "+finaltotal);
		
		conversion =(double) Math.round(finaltotal);
		System.out.println("Conversion"+"    "+conversion);
		
		roundoff=(double)Math.round((conversion-finaltotal)*100)/100;
		System.out.println("RoundOff"+"    "+roundoff);
		
		conversionfinal= Double.valueOf(conversion).intValue();
		System.out.println("Conversion Final"+"    "+conversionfinal);
		
		word = Double.valueOf(conversion).intValue();
		
		String amountword = doubleConvert(word);
		System.out.println(amountword);
		
		pstmt9=con.prepareStatement("update airwaybills set Words=? where Consignor=? and Date between ?and ? and Code=?");
		pstmt9.setString(1,amountword);
		pstmt9.setString(2, cname.getEditor().getText());
		pstmt9.setString(3, from);
		pstmt9.setString(4, to);
		pstmt9.setString(5, code.getText());
		pstmt9.executeUpdate();
		
		
		pstmt1=con.prepareStatement("update airwaybills set GrandTotal=? where Consignor=? and Date between ? and ? and Code=?");
		pstmt1.setDouble(1,finaltotal);
		pstmt1.setString(2, cname.getEditor().getText());
		pstmt1.setString(3, from);
		pstmt1.setString(4, to);
		pstmt1.setString(5, code.getText());
		pstmt1.executeUpdate();
		
		
		//convert = Double.valueOf(tot).longValue();
		//System.out.println(tot);
		//System.out.println(convert);
		//System.out.println(roundoff);
		//System.out.println(conversion);

		tot=0.00;
	}
	
}


public void tottax() throws SQLException, ClassNotFoundException
{
	Class.forName("com.mysql.jdbc.Driver");
	con=DriverManager.getConnection("jdbc:mysql://localhost:3306/sun","root","root");
	
	if( to.getEditor().getText().isEmpty())
	{
		LocalDate localDate = from.getValue();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		String date = localDate.format(formatter);
		
	
	rsviewbno.beforeFirst();
	while(rsviewbno.next()) 
	{
		tox+=(Double.parseDouble(rsviewbno.getString("Tax")));
		//System.out.println(tox);	
	}
	pstmt2=con.prepareStatement("update airwaybills set VTax=? where Consignor=? and Date=? and Code=?");
	pstmt2.setDouble(1,tox);
	pstmt2.setString(2, cname.getEditor().getText());
	pstmt2.setString(3, date);
	pstmt2.setString(4, code.getText());
	pstmt2.executeUpdate();
	tox=0.00;
	}
	else
	{
		LocalDate fromDate = from.getValue();
		DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		String from = fromDate.format(formatter1);
		
		LocalDate todate = to.getValue();
		DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		String to = todate.format(formatter2);
		rsviewdt.beforeFirst();
		while(rsviewdt.next()) 
		{
			tox+=(Double.parseDouble(rsviewdt.getString("Tax")));
			//System.out.println(tox);	
		}
		pstmt2=con.prepareStatement("update airwaybills set VTax=? where Consignor=? and Date between ? and ? and Code=?");
		pstmt2.setDouble(1,tox);
		pstmt2.setString(2, cname.getEditor().getText());
		pstmt2.setString(3, from);
		pstmt2.setString(4, to);
		pstmt2.setString(5, code.getText());
		pstmt2.executeUpdate();
		tox=0.00;
	}
		
}
	
	
	public void clear1() 
	{
		for (int i= 0 ;i < table.getItems().size(); i++) 
		   {
			table.getItems().clear();
			}
		   tableserial=1;
		
	}
	

	public void clear() 
	 {
		initialize(null,null);
		cname.getSelectionModel().clearSelection();
		cname.getEditor().clear();
		from.setValue(null);
		to.setValue(null);
		invoice.clear();
		code.clear();
		ivdate.setValue(null);
		//from.getEditor().clear();
		//to.getEditor().clear();
		
		   for (int i= 0 ;i < table.getItems().size(); i++) 
		   {
			table.getItems().clear();
			}
		   tableserial=1;
		   conversion=0.00;
		   roundoff=0.00;
		   ctax=0.00;
		   stax=0.00;
		   finaltotal=0.00;
		   sheen=0.00;
	}
	
	public void print() throws JRException, SQLException, ClassNotFoundException, IOException 
	{
			Map<String, Object> map=new HashMap<>();
			
			list=new ArrayList<>();
			
			
			if(to.getEditor().getText().isEmpty())
			{
				LocalDate fromDate = from.getValue();
				DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("yyyy-MM-dd");
				String from1 = fromDate.format(formatter1);
				
				LocalDate invdate = ivdate.getValue();
				DateTimeFormatter formatter6 = DateTimeFormatter.ofPattern("dd-MM-yyyy");
				String ivd = invdate.format(formatter6);
				
				pstmt=con.prepareStatement("SELECT *, DATE_FORMAT(Date, \"%d-%m-%Y\") as Data FROM airwaybills where Consignor=? and Date =? and Code=?");
				pstmt.setString(1, cname.getEditor().getText());
				pstmt.setString(2,from1);
				pstmt.setString(3, code.getText());
				ResultSet result = pstmt.executeQuery();
				
				
			//pudhu=viewbillno.executeQuery();
			JRResultSetDataSource jasper = new JRResultSetDataSource(result);
			JasperPrint jp = JasperFillManager.fillReport("C:\\jasper\\sunsingle.jasper",map,jasper);
			JasperViewer jv = new JasperViewer(jp,false);
			jv.setVisible(true);
			list.add(jp);
			/*File pdfFile = new File("C:\\images\\MarkSheet.xls");
			pdfFile.createNewFile();
			JRPdfExporter exporter = new JRPdfExporter();
			exporter.setExporterInput(SimpleExporterInput.getInstance(list));
			exporter.setExporterOutput(new SimpleOutputStreamExporterOutput("C:/images/MarkSheet.PDF"));
			exporter.exportReport();
			if (Desktop.isDesktopSupported()){
				Desktop.getDesktop().open(pdfFile);
			}*/
		
			}
			else
			{
				
				
				LocalDate fromDate = from.getValue();
				DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("yyyy-MM-dd");
				String from1 = fromDate.format(formatter1);
				
				LocalDate todate = to.getValue();
				DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("yyyy-MM-dd");
				String to1 = todate.format(formatter2);
				
				LocalDate frontdate = from.getValue();
				DateTimeFormatter formatter4 = DateTimeFormatter.ofPattern("dd-MM-yyyy");
				String front1 = frontdate.format(formatter4);
				
				LocalDate frontdate2 = to.getValue();
				DateTimeFormatter formatter5 = DateTimeFormatter.ofPattern("dd-MM-yyyy");
				String front2 = frontdate2.format(formatter5);
				
				LocalDate invdate = ivdate.getValue();
				DateTimeFormatter formatter6 = DateTimeFormatter.ofPattern("dd-MM-yyyy");
				String ivd = invdate.format(formatter6);
				
				
				
				/*while (result.next())
				{
					String Vishnu= (result.getString("Data"));
					System.out.println(Vishnu);
				}*/
				
				
				PreparedStatement jega=con.prepareStatement("select count(Consignor) as Value from airwaybills where Consignor=? and Date between ? and ? and Code=?");
				jega.setString(1, cname.getEditor().getText());
				jega.setString(2, from1);
				jega.setString(3, to1);
				jega.setString(4, code.getText());
				ResultSet rs11=jega.executeQuery();
				while(rs11.next())
				{
					map.put("No", rs11.getString("Value"));
				}
				
				
				map.put("Total", sheen);
				map.put("CTax", ctax);
				map.put("STax", stax);
				
				map.put("Conversion", conversionfinal);
				map.put("Round", roundoff);
				
				map.put("FromDate",front1);
				map.put("ToDate", front2 );
				map.put("InDate", ivd);
				
				PreparedStatement place = con.prepareStatement("select Place from customerdetails where Name=? and Code=?");
				place.setString(1, cname.getEditor().getText());
				place.setString(2, code.getText());
				ResultSet placeset=place.executeQuery();
				while (placeset.next())
				{
					map.put("PlaceC", placeset.getString("Place"));
				}
				//ajith=viewdate.executeQuery();
				
				pstmt=con.prepareStatement("SELECT *, DATE_FORMAT(Date, \"%d-%m-%Y\") as Data FROM airwaybills where Consignor=? and Date between ? and ? and Code=?");
				pstmt.setString(1, cname.getEditor().getText());
				pstmt.setString(2,from1);
				pstmt.setString(3,to1);
				pstmt.setString(4, code.getText());
				ResultSet result = pstmt.executeQuery();
				
				
				JRResultSetDataSource jasper = new JRResultSetDataSource(result);
				JasperPrint jp = JasperFillManager.fillReport("C:\\jasper\\SunBulk.jasper",map,jasper);
				JasperViewer jv = new JasperViewer(jp,false);
				jv.setVisible(true);
				
				
				
				ajith=viewdate.executeQuery();
				JRResultSetDataSource jasper1 = new JRResultSetDataSource(ajith);
				JasperPrint jp1 = JasperFillManager.fillReport("C:\\jasper\\Cover.jasper",map,jasper1);
				JasperViewer jv1 = new JasperViewer(jp1,false);
				jv1.setVisible(true);
				
				//roundoff=0;
				
			}
			
			}
			
	

	public void printa() throws JRException, SQLException, ClassNotFoundException 
	{
		Map<String, Object> map=new HashMap<>();
		
		list=new ArrayList<>();
		
		
		if(to.getEditor().getText().isEmpty())
		{
			LocalDate fromDate = from.getValue();
			DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			String from1 = fromDate.format(formatter1);
			
			pstmt=con.prepareStatement("SELECT *, DATE_FORMAT(Date, \"%d-%m-%Y\") as Data FROM airwaybills where Consignor=? and Date =?");
			pstmt.setString(1, cname.getEditor().getText());
			pstmt.setString(2,from1);
			ResultSet result = pstmt.executeQuery();
			
			LocalDate invdate = ivdate.getValue();
			DateTimeFormatter formatter6 = DateTimeFormatter.ofPattern("dd-MM-yyyy");
			String ivd = invdate.format(formatter6);
			
			map.put("InDate", ivd);
			
		//pudhu=viewbillno.executeQuery();
		JRResultSetDataSource jasper = new JRResultSetDataSource(result);
		JasperPrint jp = JasperFillManager.fillReport("C:\\jasper\\SunSingleA4.jasper",map,jasper);
		JasperViewer jv = new JasperViewer(jp,false);
		jv.setVisible(true);
		list.add(jp);
		/*File pdfFile = new File("C:\\images\\MarkSheet.xls");
		pdfFile.createNewFile();
		JRPdfExporter exporter = new JRPdfExporter();
		exporter.setExporterInput(SimpleExporterInput.getInstance(list));
		exporter.setExporterOutput(new SimpleOutputStreamExporterOutput("C:/images/MarkSheet.PDF"));
		exporter.exportReport();
		if (Desktop.isDesktopSupported()){
			Desktop.getDesktop().open(pdfFile);
		}*/
	
		}
		else
		{
			
			
			LocalDate fromDate = from.getValue();
			DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			String from1 = fromDate.format(formatter1);
			
			LocalDate todate = to.getValue();
			DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			String to1 = todate.format(formatter2);
			
			LocalDate frontdate = from.getValue();
			DateTimeFormatter formatter4 = DateTimeFormatter.ofPattern("dd-MM-yyyy");
			String front1 = frontdate.format(formatter4);
			
			LocalDate frontdate2 = to.getValue();
			DateTimeFormatter formatter5 = DateTimeFormatter.ofPattern("dd-MM-yyyy");
			String front2 = frontdate2.format(formatter5);
			
			LocalDate invdate = ivdate.getValue();
			DateTimeFormatter formatter6 = DateTimeFormatter.ofPattern("dd-MM-yyyy");
			String ivd = invdate.format(formatter6);
			
			
			pstmt=con.prepareStatement("SELECT *, DATE_FORMAT(Date, \"%d-%m-%Y\") as Data FROM airwaybills where Consignor=? and Date between ? and ? and Code=?");
			pstmt.setString(1, cname.getEditor().getText());
			pstmt.setString(2,from1);
			pstmt.setString(3,to1);
			pstmt.setString(4, code.getText());
			ResultSet result = pstmt.executeQuery();
			/*while (result.next())
			{
				String Vishnu= (result.getString("Data"));
				System.out.println(Vishnu);
			}
			*/
			
			PreparedStatement jega=con.prepareStatement("select count(Consignor) as Value from airwaybills where Consignor=? and Date between ? and ? and Code=?");
			jega.setString(1, cname.getEditor().getText());
			jega.setString(2, from1);
			jega.setString(3, to1);
			jega.setString(4, code.getText());
			ResultSet rs11=jega.executeQuery();
			while(rs11.next())
			{
				map.put("No", rs11.getString("Value"));
			}
			
			map.put("Total", sheen);
			map.put("CTax", ctax);
			map.put("STax", stax);
			
			map.put("Conversion", conversionfinal);
			map.put("Round", roundoff);
			
			map.put("FromDate",front1);
			map.put("ToDate",front2);
			map.put("InDate",ivd);

			PreparedStatement place = con.prepareStatement("select Place from customerdetails where Name=? and Code=?");
			place.setString(1, cname.getEditor().getText());
			place.setString(2, code.getText());
			ResultSet placeset=place.executeQuery();
			while (placeset.next())
			{
				map.put("PlaceC", placeset.getString("Place"));
			}
			
			//ajith=viewdate.executeQuery();
			JRResultSetDataSource jasper = new JRResultSetDataSource(result);
			JasperPrint jp = JasperFillManager.fillReport("C:\\jasper\\SunBulkA4.jasper",map,jasper);
			JasperViewer jv = new JasperViewer(jp,false);
			jv.setVisible(true);
			
			ajith=viewdate.executeQuery();
			JRResultSetDataSource jasper1 = new JRResultSetDataSource(ajith);
			JasperPrint jp1 = JasperFillManager.fillReport("C:\\jasper\\CoverA4.jasper",map,jasper1);
			JasperViewer jv1 = new JasperViewer(jp1,false);
			jv1.setVisible(true);
			//roundoff=0;
			
		}		
	}
    

	public static String doubleConvert(final double n) 

	{
	String pass = n + "";
	StringTokenizer token = new StringTokenizer(pass, ".");
	String first = token.nextToken();
	String last = token.nextToken();
	pass = convert(Integer.parseInt(first)) + " ";
	pass = pass + "ONLY.";
	
	/*try {
		pass = convert(Integer.parseInt(first)) + " ";
		pass = pass + "POINT";
		for (int i = 0; i < last.length(); i++) {
			String get = convert(Integer.parseInt(last.charAt(i) + ""));
			if (get.isEmpty()) {
				pass = pass + " " + "ZERO";
			} else {
				pass = pass + " " + get;
			}
		}

	} catch (NumberFormatException nf) {
	}*/
	return pass;
}

	public static String convert(final int n) 
	{
	if (n < 0) {
		return "minus " + convert(-n);
	}

	if (n < 20) {
		return units[n];
	}

	if (n < 100) {
		return tens[n / 10] + ((n % 10 != 0) ? " " : "") + units[n % 10];
	}

	if (n < 1000) {
		return units[n / 100] + " HUNDRED " + ((n % 100 != 0) ? " " : "") + convert(n % 100);
	}

	if (n < 100000) {
		return convert(n / 1000) + " THOUSAND " + ((n % 1000 != 0) ? " " : "") + convert(n % 1000);
	}

	if (n < 10000000) {
		return convert(n / 100000) + " LAKH " + ((n % 100000 != 0) ? " " : "") + convert(n % 100000);
	}

	return convert(n / 10000000) + " CRORE " + ((n % 10000000 != 0) ? " " : "") + convert(n % 10000000);
}


public void key(KeyEvent event) throws SQLException 
{	
 if (event.getCode()==KeyCode.TAB)
 {
	
		 PreparedStatement prep = con.prepareStatement("select InvoiceNo from airwaybills");
		 ResultSet st=prep.executeQuery();
		 while (st.next())
		 {
			String number=(st.getString("InvoiceNo"));
			if(invoice.getText().equals(number))
			{
				Alert alt = new Alert(AlertType.INFORMATION);
				alt.setTitle("Alert Message");
				alt.setContentText("This Invoice Number Already Exist");
				alt.showAndWait();
				break;
			}
		 }	 
 }
}
public void select() throws SQLException
{
		pstmt=con.prepareStatement("select Code from customerdetails where Name=?");
		pstmt.setString(1, cname.getEditor().getText());
		ResultSet code1=pstmt.executeQuery();
		while (code1.next())
		{
			System.out.println(code1.getString("Code"));
			code.setText(code1.getString("Code"));
			
		}
}

}
