package application;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class AWBTable {
	public SimpleIntegerProperty serial;
	public SimpleStringProperty billno;
	public SimpleStringProperty phoneno;
	public SimpleStringProperty consignor;
	public SimpleStringProperty date;
	public SimpleStringProperty place;
	public SimpleDoubleProperty weight;
	public SimpleStringProperty address;
	public SimpleIntegerProperty box;
	public SimpleDoubleProperty amount;
	public SimpleDoubleProperty cgst;
	public SimpleDoubleProperty  sgst;
	public SimpleDoubleProperty fuelsurcharge;
	public SimpleDoubleProperty tax;
	
	public SimpleDoubleProperty grandtotal;



AWBTable(int serial,String billno, String phoneno,String consignor,String date,String place,Double weight,String address,int box,Double amount,Double cgst,Double sgst,Double fuelsurcharge,Double tax,Double grandtotal) {
		this.serial = new SimpleIntegerProperty(serial);
		this.billno = new SimpleStringProperty(billno);
		this.phoneno = new SimpleStringProperty(phoneno);
		this.consignor = new SimpleStringProperty(consignor);
		this.date = new SimpleStringProperty(date);
		this.place = new SimpleStringProperty(place);
		this.weight = new SimpleDoubleProperty(weight);
		this.address=new SimpleStringProperty(address);
		this.box= new SimpleIntegerProperty(box);
		this.amount = new SimpleDoubleProperty(amount);
		this.cgst = new SimpleDoubleProperty(cgst);
		this.sgst = new SimpleDoubleProperty(sgst);
		this.fuelsurcharge= new SimpleDoubleProperty(fuelsurcharge);
		this.tax = new SimpleDoubleProperty(tax);
		this.grandtotal = new SimpleDoubleProperty(grandtotal);
	}

	public AWBTable(double grandtotal) 
	{
		this.grandtotal = new SimpleDoubleProperty(grandtotal);
	}
	
	
public IntegerProperty serialProperty(){
	return serial;
	
}
public StringProperty billnoProperty(){
	return billno;
}
public StringProperty phonenoProperty(){
	return phoneno;
}
public StringProperty consignorProperty(){
	return consignor;
}
public StringProperty dateProperty(){
	return date;
}
public StringProperty placeProperty(){
	return place;
}

public DoubleProperty weightProperty(){
	return weight;
}
public StringProperty addressProperty() {
	return address;
}

	public IntegerProperty boxProperty(){
		return box;
	}

public DoubleProperty cgstProperty(){
	return cgst;

}
public DoubleProperty sgstProperty(){
	return sgst;

}
public DoubleProperty amountProperty(){
	return amount;

}
public DoubleProperty fuelsurchargeProperty(){
	return fuelsurcharge;
}
public DoubleProperty taxProperty(){
	return tax;


}
public DoubleProperty grandtotalProperty(){
	return grandtotal;
}
}

