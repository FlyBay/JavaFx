package application;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;

import javax.mail.internet.AddressException;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
public class SampleController {
	public TextField userid;
	public PasswordField passid;
	Connection con;
	PreparedStatement pstmt;
	ResultSet rs;
	String user;
	String password;
	public void login(ActionEvent event) throws IOException{
		try {
					
					Class.forName("com.mysql.jdbc.Driver");
					con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sun", "root", "root");
					pstmt = con.prepareStatement("select username,password from login");
					rs = pstmt.executeQuery();
					while (rs.next()) {
						user = rs.getString("username");
						password = rs.getString("password");
					}
					if (user.equals(userid.getText()) && password.equals(passid.getText())) {
						((Node) event.getSource()).getScene().getWindow().hide();
						Parent root = FXMLLoader.load(getClass().getResource("TabSun.fxml"));
						Scene scene = new Scene(root, 400, 400);
						scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
						Stage primaryStage = new Stage();
						primaryStage.setMaximized(true);
						primaryStage.setScene(scene);
						primaryStage.show();
					} else {
						Alert alt = new Alert(AlertType.INFORMATION);
						alt.setTitle("DB Con Check");
						alt.setContentText("Enter valid username and password");
						alt.showAndWait();
					}
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
	public void keyPressed(KeyEvent event) throws IOException, SQLException, AddressException, ParseException 
	{	
	
		if(event.getCode().equals(KeyCode.ENTER))
		{
			
			try {
				
				Class.forName("com.mysql.jdbc.Driver");
				con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sun", "root", "root");
				pstmt = con.prepareStatement("select username,password from login");
				rs = pstmt.executeQuery();
				while (rs.next()) {
					user = rs.getString("username");
					password = rs.getString("password");
				}
				if (user.equals(userid.getText()) && password.equals(passid.getText())) {
					((Node) event.getSource()).getScene().getWindow().hide();
					Parent root = FXMLLoader.load(getClass().getResource("TabSun.fxml"));
					Scene scene = new Scene(root, 400, 400);
					scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
					Stage primaryStage = new Stage();
					primaryStage.setMaximized(true);
					primaryStage.setScene(scene);
					primaryStage.show();
				} else {
					Alert alt = new Alert(AlertType.INFORMATION);
					alt.setTitle("DB Con Check");
					alt.setContentText("Enter valid username and password");
					alt.showAndWait();
				}
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
			else
			{
				Alert alt = new Alert(AlertType.INFORMATION);
				alt.setTitle("Login Alert");
				alt.setHeaderText("Login Failed");
				alt.showAndWait();
			}

		}
}
