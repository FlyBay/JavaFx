package application;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.StringTokenizer;

import javax.mail.internet.AddressException;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import com.sun.javafx.scene.control.SelectedCellsMap;

import javafx.application.Platform;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TablePosition;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import javafx.util.Callback;
//import net.sf.jasperreports.engine.JRException;
//import net.sf.jasperreports.engine.JRResultSetDataSource;
//import net.sf.jasperreports.engine.JasperCompileManager;
//import net.sf.jasperreports.engine.JasperFillManager;
//import net.sf.jasperreports.engine.JasperPrint;
//import net.sf.jasperreports.engine.JasperReport;
//import net.sf.jasperreports.engine.design.JasperDesign;
//import net.sf.jasperreports.engine.xml.JRXmlLoader;
//import net.sf.jasperreports.view.JasperViewer;  
public class Customer implements Initializable {
	public TextField code,name,place,email,phoneno,cgst,sgst,fax,gst;
	 public TextArea address;
	 public TableView customer;
	 public TableColumn<customertable,String>viewcode,viewname,viewaddress,viewplace,viewmail,viewphnno,viewfax,tgst;
	 public TableColumn<customertable,Double>viewcgst,viewsgst,viewfuel;
	 ObservableList<customertable> list1 = FXCollections.observableArrayList();
	 ObservableList<customertable> list2 = FXCollections.observableArrayList();
	 
	
	Connection connect;
	PreparedStatement pstmt,pstmt1,pst;
	ResultSet rs, rs1, rs2,rs3;
	Statement stmt, stmt1,stmt2;

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
		try {
			
			Class.forName("com.mysql.jdbc.Driver");
			connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/sun", "root", "root");
			
			
			pstmt = connect.prepareStatement("select * from customerdetails");
			rs2 = pstmt.executeQuery();
			while (rs2.next()) {
				list2.add(new customertable(rs2.getString("Code"),
						rs2.getString("Name"), rs2.getString("Address"), rs2.getString("Place"),
						rs2.getString("Emailaddress"), rs2.getString("Phoneno"),rs2.getDouble("CGST"),rs2.getDouble("SGST"),rs2.getString("Fax"),rs2.getString("GSTNo")));
			}
			viewcode.setCellValueFactory(new PropertyValueFactory<customertable, String>("pojocode"));
			viewname.setCellValueFactory(new PropertyValueFactory<customertable, String>("pojoname"));
			viewaddress.setCellValueFactory(new PropertyValueFactory<customertable, String>("pojoaddress"));
			viewplace .setCellValueFactory(new PropertyValueFactory<customertable, String>("pojoplace"));
			viewmail.setCellValueFactory(new PropertyValueFactory<customertable, String>("pojomail"));		
			viewphnno.setCellValueFactory(new PropertyValueFactory<customertable, String>("pojophnno"));
			viewcgst.setCellValueFactory(new PropertyValueFactory<customertable, Double>("pojocgst"));		
			viewsgst.setCellValueFactory(new PropertyValueFactory<customertable, Double>("pojosgst"));
			viewfax.setCellValueFactory(new PropertyValueFactory<customertable, String>("pojofax"));
			tgst.setCellValueFactory(new PropertyValueFactory<customertable, String>("pojogst"));
			customer.setItems(list2);
			
			stmt2=connect.createStatement();
			rs3=stmt2.executeQuery("SELECT SUBSTRING(Code, 3, 1000000000) AS ExtractString FROM customerdetails");
			rs3.last();
			int i=Integer.parseInt(rs3.getString("ExtractString"));
			int j=i+1;
			String k="SL" + Integer.toString(j);
			code.setText(k);
			System.out.println(k);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public void add() throws SQLException
	{
	
			pstmt = connect.prepareStatement("insert into customerdetails(Code,Name,Address,Place,Emailaddress,Phoneno,CGST,SGST,Fax,GSTNo) Values(?,?,?,?,?,?,?,?,?,?)");
			pstmt.setString(1, code.getText());
			pstmt.setString(2, name.getText());
			pstmt.setString(3, address.getText());
			pstmt.setString(4, place.getText());
			pstmt.setString(5, email.getText());
			pstmt.setString(6, phoneno.getText());
			pstmt.setString(7, cgst.getText());
			pstmt.setString(8, sgst.getText());
			pstmt.setString(9, fax.getText());
			pstmt.setString(10, gst.getText());
			int rs = pstmt.executeUpdate();
			clear();
			clearmethod();
			initialize(null,null);
	}
		
		
	public void clear()
	{
		for (int i=0;i< customer.getItems().size();i++)
		{
			customer.getItems().clear();
		}
	}
	
	public void click()
	{
		customertable retrive=(customertable) customer.getSelectionModel().getSelectedItem();
		code.setText(retrive.pojocode.get());
		name.setText(retrive.pojoname.get());
		address.setText(retrive.pojoaddress.get());
		place.setText(retrive.pojoplace.get());
		email.setText(retrive.pojomail.get());
		phoneno.setText(retrive.pojophnno.get());
		cgst.setText(Double.toString(retrive.pojocgst.get()));
		sgst.setText(Double.toString(retrive.pojosgst.get()));
		fax.setText(retrive.pojofax.get());	
		gst.setText(retrive.pojogst.get());
	}
	
	public void clearmethod()
	{
			code.clear();
			name.clear();
			address.clear();
			place.clear();
			email.clear();
			phoneno.clear();
			cgst.clear();
			sgst.clear();
			fax.clear();
			gst.clear();
	}
	
	public void update() throws SQLException
	{
		pstmt1 = connect.prepareStatement("update customerdetails set Name=?,Address=?,Place=?,Emailaddress=?,Phoneno=?,CGST=?,SGST=?,Fax=?,GSTNo=? where Code=?");
		pstmt1.setString(1, name.getText());
		pstmt1.setString(2, address.getText());
		pstmt1.setString(3, place.getText());
		pstmt1.setString(4, email.getText());
		pstmt1.setString(5, phoneno.getText());
		pstmt1.setString(6, cgst.getText());
		pstmt1.setString(7, sgst.getText());
		pstmt1.setString(8, fax.getText());
		pstmt1.setString(9, gst.getText());
		pstmt1.setString(10, code.getText());
		pstmt1.executeUpdate();
		clear();
		clearmethod();
		initialize(null,null);
		
	} 
	public void delete()
	{
		try
		{
			Alert alert = new Alert(AlertType.CONFIRMATION);
			alert.setTitle("Confirmation Dialog");
			alert.setHeaderText("Do You Want To Delete");
			
			Optional<ButtonType> result = alert.showAndWait();
			if (result.get() == ButtonType.OK){
				pst=connect.prepareStatement("delete from Customerdetails where Code=?");
				pst.setString(1, code.getText());
				pst.executeUpdate();
				
				   Alert alert1=new Alert(AlertType.INFORMATION);
					alert1.setContentText("Deleted Successfully");
		            alert1.show();
			}
	}
		catch(Exception e)
		{
		e.printStackTrace();
		}
		clear();
		clearmethod();
		initialize(null,null);
		
}
	
	public void enter(KeyEvent event) throws IOException, SQLException, AddressException, ParseException 
	{	
	
		if(event.getCode().equals(KeyCode.ENTER))
		{
			add();
		}
	}

}