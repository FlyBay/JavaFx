package application;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Optional;
import java.util.ResourceBundle;

import javax.naming.spi.DirStateFactory.Result;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;
public class searchform implements Initializable{
	public TableView searchtable;
	public  ComboBox cname,townname;
	public TextField air,totalweight,totalbox,code;
	public DatePicker date,to;
	public TableColumn<SearchTable, Integer> tablesno,tablebox;
	public TableColumn<SearchTable, String> tabledate,tablebillno,tablename,tableaddress,tabledestination,tablephnno;
	public TableColumn<SearchTable, Double> tableweight,tablebase,tablefuel,tabletax,tabletotal;
	public TableColumn<SearchTable, String>SearchTable;
	static int tableserial=1;
	Connection con;
	PreparedStatement pstmt,pst,pstmt1,pstmt2,pre,pstmt3;
	ResultSet rs,rs1,rs2,re,rs3,rs6,rs7;
	ObservableList list2 = FXCollections.observableArrayList();
	ObservableList list1 = FXCollections.observableArrayList();
	ObservableList list3 = FXCollections.observableArrayList();
	ObservableList list4 = FXCollections.observableArrayList();
	static double total=0.00,totalb=0.00;
	static Date setdate;
	
	@SuppressWarnings("unchecked")
	public void initialize(URL arg0,ResourceBundle arg1)
	{
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sun", "root", "root");
			pstmt1 = con.prepareStatement("select*from airwaybills");
			rs1 = pstmt1.executeQuery();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			
		pstmt2 = con.prepareStatement("select distinct Consignor from airwaybills");
		list2 = FXCollections.observableArrayList();
		rs2=pstmt2.executeQuery();
	    
		while (rs2.next()) 
		{
			list2.add(rs2.getString("Consignor"));
		}
		cname.setEditable(true);
		cname.setItems(list2);
		new AutoCompleteComboBoxListener<>(cname);
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
			
			try 
			{
				list3 = FXCollections.observableArrayList();
				pstmt3 = con.prepareStatement("select distinct TownName from tariffentry");
				rs3=pstmt3.executeQuery();
				while (rs3.next()) 
				{
					list3.add(rs3.getString("TownName"));
				}
				townname.setEditable(true);
				townname.setItems(list3);
				new AutoCompleteComboBoxListener<>(townname);
			}
			
			catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
	}
		
	@SuppressWarnings("unchecked")
	public void tablesearch() throws SQLException 
	{
		clear1();
		
		if(to.getEditor().getText().isEmpty() && date.getEditor().getText().isEmpty() && cname.getEditor().getText().isEmpty() && townname.getEditor().getText().isEmpty() )
		{
			pstmt = con.prepareStatement("select * from airwaybills where AirWayBillNo=?");
			pstmt.setString(1, air.getText());
			
		ResultSet	v = pstmt.executeQuery();
			while (v.next()) 
			{
				list1.add(new SearchTable(tableserial, v.getString("AirwayBillNo"),v.getString("Date"),v.getString("Consignor"),v.getString("ConsignorAddress"),v.getString("Place"),v.getString("PhoneNo"),
									v.getDouble("Weight"),v.getInt("Box"),v.getDouble("Amount"),v.getDouble("FuelSurcharge"),v.getDouble("Tax"),v.getDouble("TotalAmount")));
									tableserial++;	
			}
			tablesno.setCellValueFactory(new PropertyValueFactory<SearchTable, Integer>("pojosno"));
			tablebillno.setCellValueFactory(new PropertyValueFactory<SearchTable, String>("pojobillno"));
			tabledate.setCellValueFactory(new PropertyValueFactory<SearchTable, String>("pojodate"));
			tablename.setCellValueFactory(new PropertyValueFactory<SearchTable, String>("pojoclientcname"));
			tableaddress.setCellValueFactory(new PropertyValueFactory<SearchTable, String>("pojoaddress"));
			tabledestination.setCellValueFactory(new PropertyValueFactory<SearchTable, String>("pojodestination"));
			tablephnno.setCellValueFactory(new PropertyValueFactory<SearchTable, String>("pojophnno"));
			tableweight.setCellValueFactory(new PropertyValueFactory<SearchTable, Double>("pojoweight"));
			tablebox.setCellValueFactory(new PropertyValueFactory<SearchTable, Integer>("pojobox"));
			tablebase.setCellValueFactory(new PropertyValueFactory<SearchTable, Double>("pojobasevalue"));
			tablefuel.setCellValueFactory(new PropertyValueFactory<SearchTable, Double>("pojofuel"));
			tabletax.setCellValueFactory(new PropertyValueFactory<SearchTable, Double>("pojotax"));
			tabletotal.setCellValueFactory(new PropertyValueFactory<SearchTable, Double>("pojototal"));
			searchtable.setItems(list1);
			
		}
		
		
		else if(to.getEditor().getText().isEmpty() && date.getEditor().getText().isEmpty() && air.getText().isEmpty() && townname.getEditor().getText().isEmpty() )
		{
			pstmt = con.prepareStatement("select * from airwaybills where Consignor=?");
			pstmt.setString(1, cname.getEditor().getText());
			
			ResultSet	vi = pstmt.executeQuery();
			while (vi.next()) 
			{
				list1.add(new SearchTable(tableserial, vi.getString("AirwayBillNo"),vi.getString("Date"),vi.getString("Consignor"),vi.getString("ConsignorAddress"),vi.getString("Place"),vi.getString("PhoneNo"),
									vi.getDouble("Weight"),vi.getInt("Box"),vi.getDouble("Amount"),vi.getDouble("FuelSurcharge"),vi.getDouble("Tax"),vi.getDouble("TotalAmount")));
				tableserial++;
				
				//setdate=vi.getString("Date");
				
				//DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
				//String date = setdate.format(formatter);
				
				total+=(vi.getDouble("Weight"));
				totalb+=(Double.parseDouble(Integer.toString(vi.getInt("Box"))));
				totalweight.setText(Double.toString(total));
				totalbox.setText(Double.toString(totalb));
			}
			tablesno.setCellValueFactory(new PropertyValueFactory<SearchTable, Integer>("pojosno"));
			tablebillno.setCellValueFactory(new PropertyValueFactory<SearchTable, String>("pojobillno"));
			tabledate.setCellValueFactory(new PropertyValueFactory<SearchTable, String>("pojodate"));
			tablename.setCellValueFactory(new PropertyValueFactory<SearchTable, String>("pojoclientcname"));
			tableaddress.setCellValueFactory(new PropertyValueFactory<SearchTable, String>("pojoaddress"));
			tabledestination.setCellValueFactory(new PropertyValueFactory<SearchTable, String>("pojodestination"));
			tablephnno.setCellValueFactory(new PropertyValueFactory<SearchTable, String>("pojophnno"));
			tableweight.setCellValueFactory(new PropertyValueFactory<SearchTable, Double>("pojoweight"));
			tablebox.setCellValueFactory(new PropertyValueFactory<SearchTable, Integer>("pojobox"));
			tablebase.setCellValueFactory(new PropertyValueFactory<SearchTable, Double>("pojobasevalue"));
			tablefuel.setCellValueFactory(new PropertyValueFactory<SearchTable, Double>("pojofuel"));
			tabletax.setCellValueFactory(new PropertyValueFactory<SearchTable, Double>("pojotax"));
			tabletotal.setCellValueFactory(new PropertyValueFactory<SearchTable, Double>("pojototal"));
			searchtable.setItems(list1);
			
		}
		
		
		else if(to.getEditor().getText().isEmpty() && date.getEditor().getText().isEmpty() && cname.getEditor().getText().isEmpty())
		{
			pstmt = con.prepareStatement("select * from airwaybills where Place=?");
			pstmt.setString(1, townname.getEditor().getText());
			ResultSet rs200 = pstmt.executeQuery();
			while (rs200.next()) 
			{
				list1.add(new SearchTable(tableserial, rs200.getString("AirwayBillNo"),rs200.getString("Date"),rs200.getString("Consignor"),rs200.getString("ConsignorAddress"),rs200.getString("Place"),rs200.getString("PhoneNo"),
									rs200.getDouble("Weight"),rs200.getInt("Box"),rs200.getDouble("Amount"),rs200.getDouble("FuelSurcharge"),rs200.getDouble("Tax"),rs200.getDouble("TotalAmount")));
									tableserial++;
									
									total+=(rs200.getDouble("Weight"));
									totalb+=(Double.parseDouble(Integer.toString(rs200.getInt("Box"))));
									totalweight.setText(Double.toString(total));
									totalbox.setText(Double.toString(totalb));
								//	System.out.println(tableserial);
							
			}
			tablesno.setCellValueFactory(new PropertyValueFactory<SearchTable, Integer>("pojosno"));
			tablebillno.setCellValueFactory(new PropertyValueFactory<SearchTable, String>("pojobillno"));
			tabledate.setCellValueFactory(new PropertyValueFactory<SearchTable, String>("pojodate"));
			tablename.setCellValueFactory(new PropertyValueFactory<SearchTable, String>("pojoclientcname"));
			tableaddress.setCellValueFactory(new PropertyValueFactory<SearchTable, String>("pojoaddress"));
			tabledestination.setCellValueFactory(new PropertyValueFactory<SearchTable, String>("pojodestination"));
			tablephnno.setCellValueFactory(new PropertyValueFactory<SearchTable, String>("pojophnno"));
			tableweight.setCellValueFactory(new PropertyValueFactory<SearchTable, Double>("pojoweight"));
			tablebox.setCellValueFactory(new PropertyValueFactory<SearchTable, Integer>("pojobox"));
			tablebase.setCellValueFactory(new PropertyValueFactory<SearchTable, Double>("pojobasevalue"));
			tablefuel.setCellValueFactory(new PropertyValueFactory<SearchTable, Double>("pojofuel"));
			tabletax.setCellValueFactory(new PropertyValueFactory<SearchTable, Double>("pojotax"));
			tabletotal.setCellValueFactory(new PropertyValueFactory<SearchTable, Double>("pojototal"));
			searchtable.setItems(list1);
		}
		
		
		
		else if(to.getEditor().getText().isEmpty() && date.getEditor().getText().isEmpty())
		{
			pstmt = con.prepareStatement("select * from airwaybills where Consignor=? and Place=?");
			pstmt.setString(1, cname.getEditor().getText());
			pstmt.setString(2, townname.getEditor().getText());
			rs = pstmt.executeQuery();
			while (rs.next()) 
			{
				list1.add(new SearchTable(tableserial, rs.getString("AirwayBillNo"),rs.getString("Date"),rs.getString("Consignor"),rs.getString("ConsignorAddress"),rs.getString("Place"),rs.getString("PhoneNo"),
									rs.getDouble("Weight"),rs.getInt("Box"),rs.getDouble("Amount"),rs.getDouble("FuelSurcharge"),rs.getDouble("Tax"),rs.getDouble("TotalAmount")));
									tableserial++;
									
									total+=(rs.getDouble("Weight"));
									totalb+=(Double.parseDouble(Integer.toString(rs.getInt("Box"))));
									totalweight.setText(Double.toString(total));
									totalbox.setText(Double.toString(totalb));
								//	System.out.println(tableserial);
							
			}
			tablesno.setCellValueFactory(new PropertyValueFactory<SearchTable, Integer>("pojosno"));
			tablebillno.setCellValueFactory(new PropertyValueFactory<SearchTable, String>("pojobillno"));
			tabledate.setCellValueFactory(new PropertyValueFactory<SearchTable, String>("pojodate"));
			tablename.setCellValueFactory(new PropertyValueFactory<SearchTable, String>("pojoclientcname"));
			tableaddress.setCellValueFactory(new PropertyValueFactory<SearchTable, String>("pojoaddress"));
			tabledestination.setCellValueFactory(new PropertyValueFactory<SearchTable, String>("pojodestination"));
			tablephnno.setCellValueFactory(new PropertyValueFactory<SearchTable, String>("pojophnno"));
			tableweight.setCellValueFactory(new PropertyValueFactory<SearchTable, Double>("pojoweight"));
			tablebox.setCellValueFactory(new PropertyValueFactory<SearchTable, Integer>("pojobox"));
			tablebase.setCellValueFactory(new PropertyValueFactory<SearchTable, Double>("pojobasevalue"));
			tablefuel.setCellValueFactory(new PropertyValueFactory<SearchTable, Double>("pojofuel"));
			tabletax.setCellValueFactory(new PropertyValueFactory<SearchTable, Double>("pojotax"));
			tabletotal.setCellValueFactory(new PropertyValueFactory<SearchTable, Double>("pojototal"));
			searchtable.setItems(list1);
		}
		
		
		else if(townname.getEditor().getText().isEmpty() )
		   {
			LocalDate localDate = date.getValue();
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			String date = localDate.format(formatter);
			
			LocalDate localDate1 = to.getValue();
			DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			String to = localDate1.format(formatter1);
			
			pstmt = con.prepareStatement("select * from airwaybills where Consignor=? and Date between ? and ?");
			pstmt.setString(1, cname.getEditor().getText());
			pstmt.setString(2, date);
			pstmt.setString(3, to);
			ResultSet rs10 = pstmt.executeQuery();
			while (rs10.next()) 
			{
				list1.add(new SearchTable(tableserial, rs10.getString("AirwayBillNo"),rs10.getString("Date"),rs10.getString("Consignor"),rs10.getString("ConsignorAddress"),rs10.getString("Place"),rs10.getString("PhoneNo"),
									rs10.getDouble("Weight"),rs10.getInt("Box"),rs10.getDouble("Amount"),rs10.getDouble("FuelSurcharge"),rs10.getDouble("Tax"),rs10.getDouble("TotalAmount")));
									tableserial++;
									
									total+=(rs10.getDouble("Weight"));
									totalb+=(Double.parseDouble(Integer.toString(rs10.getInt("Box"))));
									totalweight.setText(Double.toString(total));
									totalbox.setText(Double.toString(totalb));
									
								//	System.out.println(tableserial);
							
			}
			tablesno.setCellValueFactory(new PropertyValueFactory<SearchTable, Integer>("pojosno"));
			tablebillno.setCellValueFactory(new PropertyValueFactory<SearchTable, String>("pojobillno"));
			tabledate.setCellValueFactory(new PropertyValueFactory<SearchTable, String>("pojodate"));
			tablename.setCellValueFactory(new PropertyValueFactory<SearchTable, String>("pojoclientcname"));
			tableaddress.setCellValueFactory(new PropertyValueFactory<SearchTable, String>("pojoaddress"));
			tabledestination.setCellValueFactory(new PropertyValueFactory<SearchTable, String>("pojodestination"));
			tablephnno.setCellValueFactory(new PropertyValueFactory<SearchTable, String>("pojophnno"));
			tableweight.setCellValueFactory(new PropertyValueFactory<SearchTable, Double>("pojoweight"));
			tablebox.setCellValueFactory(new PropertyValueFactory<SearchTable, Integer>("pojobox"));
			tablebase.setCellValueFactory(new PropertyValueFactory<SearchTable, Double>("pojobasevalue"));
			tablefuel.setCellValueFactory(new PropertyValueFactory<SearchTable, Double>("pojofuel"));
			tabletax.setCellValueFactory(new PropertyValueFactory<SearchTable, Double>("pojotax"));
			tabletotal.setCellValueFactory(new PropertyValueFactory<SearchTable, Double>("pojototal"));
			searchtable.setItems(list1);
		}
		
		else if(cname.getEditor().getText().isEmpty() )
		{
			LocalDate localDate = date.getValue();
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			String date = localDate.format(formatter);
			
			LocalDate localDate1 = to.getValue();
			DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			String to = localDate1.format(formatter1);
			
			pstmt = con.prepareStatement("select * from airwaybills where Place=? and Date between ? and ?");
			pstmt.setString(1, townname.getEditor().getText());
			pstmt.setString(2, date);
			pstmt.setString(3, to);
			ResultSet rs10 = pstmt.executeQuery();
			while (rs10.next()) 
			{
				list1.add(new SearchTable(tableserial, rs10.getString("AirwayBillNo"),rs10.getString("Date"),rs10.getString("Consignor"),rs10.getString("ConsignorAddress"),rs10.getString("Place"),rs10.getString("PhoneNo"),
									rs10.getDouble("Weight"),rs10.getInt("Box"),rs10.getDouble("Amount"),rs10.getDouble("FuelSurcharge"),rs10.getDouble("Tax"),rs10.getDouble("TotalAmount")));
									tableserial++;
									
									total+=(rs10.getDouble("Weight"));
									totalb+=(Double.parseDouble(Integer.toString(rs10.getInt("Box"))));
									totalweight.setText(Double.toString(total));
									totalbox.setText(Double.toString(totalb));
									
								//	System.out.println(tableserial);
							
			}
			tablesno.setCellValueFactory(new PropertyValueFactory<SearchTable, Integer>("pojosno"));
			tablebillno.setCellValueFactory(new PropertyValueFactory<SearchTable, String>("pojobillno"));
			tabledate.setCellValueFactory(new PropertyValueFactory<SearchTable, String>("pojodate"));
			tablename.setCellValueFactory(new PropertyValueFactory<SearchTable, String>("pojoclientcname"));
			tableaddress.setCellValueFactory(new PropertyValueFactory<SearchTable, String>("pojoaddress"));
			tabledestination.setCellValueFactory(new PropertyValueFactory<SearchTable, String>("pojodestination"));
			tablephnno.setCellValueFactory(new PropertyValueFactory<SearchTable, String>("pojophnno"));
			tableweight.setCellValueFactory(new PropertyValueFactory<SearchTable, Double>("pojoweight"));
			tablebox.setCellValueFactory(new PropertyValueFactory<SearchTable, Integer>("pojobox"));
			tablebase.setCellValueFactory(new PropertyValueFactory<SearchTable, Double>("pojobasevalue"));
			tablefuel.setCellValueFactory(new PropertyValueFactory<SearchTable, Double>("pojofuel"));
			tabletax.setCellValueFactory(new PropertyValueFactory<SearchTable, Double>("pojotax"));
			tabletotal.setCellValueFactory(new PropertyValueFactory<SearchTable, Double>("pojototal"));
			searchtable.setItems(list1);
		}
		
		
		else 
		{
			LocalDate localDate = date.getValue();
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			String date = localDate.format(formatter);
			
			LocalDate localDate1 = to.getValue();
			DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			String to = localDate1.format(formatter1);
			
			pstmt = con.prepareStatement("select * from airwaybills where Consignor=? and Place=? and Date between ? and ?");
			pstmt.setString(1, cname.getEditor().getText());
			pstmt.setString(2, townname.getEditor().getText());
			pstmt.setString(3, date);
			pstmt.setString(4, to);
			rs6 = pstmt.executeQuery();
			while (rs6.next()) 
			{
				list1.add(new SearchTable(tableserial, rs6.getString("AirwayBillNo"),rs6.getString("Date"),rs6.getString("Consignor"),rs6.getString("ConsignorAddress"),rs6.getString("Place"),rs6.getString("PhoneNo"),
									rs6.getDouble("Weight"),rs6.getInt("Box"),rs6.getDouble("Amount"),rs6.getDouble("FuelSurcharge"),rs6.getDouble("Tax"),rs6.getDouble("TotalAmount")));
						tableserial++;
						
						total+=(rs6.getDouble("Weight"));
						totalb+=(Double.parseDouble(Integer.toString(rs6.getInt("Box"))));
						totalweight.setText(Double.toString(total));
						totalbox.setText(Double.toString(totalb));
							
			}
			tablesno.setCellValueFactory(new PropertyValueFactory<SearchTable, Integer>("pojosno"));
			tablebillno.setCellValueFactory(new PropertyValueFactory<SearchTable, String>("pojobillno"));
			tabledate.setCellValueFactory(new PropertyValueFactory<SearchTable, String>("pojodate"));
			tablename.setCellValueFactory(new PropertyValueFactory<SearchTable, String>("pojoclientcname"));
			tableaddress.setCellValueFactory(new PropertyValueFactory<SearchTable, String>("pojoaddress"));
			tabledestination.setCellValueFactory(new PropertyValueFactory<SearchTable, String>("pojodestination"));
			tablephnno.setCellValueFactory(new PropertyValueFactory<SearchTable, String>("pojophnno"));
			tableweight.setCellValueFactory(new PropertyValueFactory<SearchTable, Double>("pojoweight"));
			tablebox.setCellValueFactory(new PropertyValueFactory<SearchTable, Integer>("pojobox"));
			tablebase.setCellValueFactory(new PropertyValueFactory<SearchTable, Double>("pojobasevalue"));
			tablefuel.setCellValueFactory(new PropertyValueFactory<SearchTable, Double>("pojofuel"));
			tabletax.setCellValueFactory(new PropertyValueFactory<SearchTable, Double>("pojotax"));
			tabletotal.setCellValueFactory(new PropertyValueFactory<SearchTable, Double>("pojototal"));
			searchtable.setItems(list1);	
		}
		
		tableserial=1;
		
		
		
		
		}
	
	public void delete()
	{
		 {
			 try
			{
				Alert alert = new Alert(AlertType.CONFIRMATION);
				alert.setTitle("Confirmation Dialog");
				alert.setHeaderText("Do You Want To Delete");
				
				Optional<ButtonType> result = alert.showAndWait();
				if (result.get() == ButtonType.OK){
					pst=con.prepareStatement("delete from airwaybills where AirwayBillNo=? and Consignor=?");
					pst.setString(1, air.getText());
					pst.setString(2, cname.getEditor().getText());
					pst.executeUpdate();
					
					   Alert alert1=new Alert(AlertType.INFORMATION);
						alert1.setContentText("Deleted Successfully");
			            alert1.show();
				}
		}
			catch(Exception e)
			{
			e.printStackTrace();
			}
	
		 }
		clear();
	}
	
	public void clear() 
	{	
		date.setValue(null);
		cname.getSelectionModel().clearSelection();
		cname.getEditor().clear();
		to.setValue(null);
		air.clear();
		townname.getSelectionModel().clearSelection();
		townname.getEditor().clear();
		totalweight.clear();
		totalbox.clear();
		code.clear();
		for (int i= 0 ;i < searchtable.getItems().size(); i++)
		{
			searchtable.getItems().clear();
		}
		
		
		initialize(null,null);
		 total=0.00;totalb=0.00;
	}
	
	public void clear1() 
	{
		for (int i= 0 ;i < searchtable.getItems().size(); i++)
		{
			searchtable.getItems().clear();
		}
	}
	
	 public void click()
	 {
		 SearchTable retrive=(SearchTable) searchtable.getSelectionModel().getSelectedItem();
		 air.setText(retrive.pojobillno.get());
		 cname.getEditor().setText(retrive.pojoclientcname.get());
		 townname.getEditor().setText(retrive.pojodestination.get());
	 }
 
	 
	 public void backup() throws ClassNotFoundException, SQLException, FileNotFoundException
	
	 {
		 if(to.getEditor().getText().isEmpty() && date.getEditor().getText().isEmpty()  && townname.getEditor().getText().isEmpty() && cname.getEditor().getText().isEmpty())
			{
				pstmt = con.prepareStatement("select * from airwaybills where AirwayBillNo=?");
				pstmt.setString(1, air.getText());
				ResultSet b2 = pstmt.executeQuery();
				
				HSSFWorkbook workbook = new HSSFWorkbook();
		 		HSSFSheet spreadsheet = workbook.createSheet("Backup");
		 		HSSFRow row = spreadsheet.createRow(1);
		 		HSSFCell cell;
		 		cell = row.createCell(1);
		 		spreadsheet.autoSizeColumn(1);
		 		cell.setCellValue("AirwayBill No");
		 		cell = row.createCell(2);
		 		spreadsheet.autoSizeColumn(2);
		 		cell.setCellValue("Date");
		 		cell = row.createCell(3);
		 		spreadsheet.autoSizeColumn(3);
		 		cell.setCellValue("Client Name");
		 		cell = row.createCell(4);
		 		spreadsheet.autoSizeColumn(4);
		 		cell.setCellValue("Destination");
		 		cell = row.createCell(5);
		 		spreadsheet.autoSizeColumn(5);
		 		cell.setCellValue("Weight");
		 		cell = row.createCell(6);
		 		spreadsheet.autoSizeColumn(6);
		 		cell.setCellValue("Box/Piece");
		 		cell = row.createCell(7);
		 		spreadsheet.autoSizeColumn(7);
		 		cell.setCellValue("Client Address");
		 		cell = row.createCell(8);
		 		spreadsheet.autoSizeColumn(8);
		 		cell.setCellValue("PhoneNo");
		 		cell = row.createCell(9);
		 		spreadsheet.autoSizeColumn(9);
		 		cell.setCellValue("Base Value");
		 		cell=row.createCell(10);
		 		spreadsheet.autoSizeColumn(10);
		 		cell.setCellValue("Fuel SurCharge");
		 		cell=row.createCell(11);
		 		spreadsheet.autoSizeColumn(11);
		 		cell.setCellValue("Tax");
		 		cell=row.createCell(12);
		 		spreadsheet.autoSizeColumn(12);
		 		cell.setCellValue("Total Amount");
		 		
		 		int rowcount = 2;
		 		while (b2.next()) 
		 		{
		 			row = spreadsheet.createRow(rowcount);
		 			cell = row.createCell(1);
		 			spreadsheet.autoSizeColumn(1);
		 			cell.setCellValue(b2.getString("AirwayBillNo"));
		 			
		 			cell = row.createCell(2);
		 			spreadsheet.autoSizeColumn(2);
		 			cell.setCellValue(b2.getString("Date"));
		 			
		 			cell = row.createCell(3);
		 			spreadsheet.autoSizeColumn(3);
		 			cell.setCellValue(b2.getString("Consignor"));
		 			
		 			cell = row.createCell(4);
		 			spreadsheet.autoSizeColumn(4);
		 			cell.setCellValue(b2.getString("Place"));
		 			
		 			cell = row.createCell(5);
		 			spreadsheet.autoSizeColumn(5);
		 			cell.setCellValue(b2.getDouble("Weight"));
		 			
		 			cell = row.createCell(6);
		 			spreadsheet.autoSizeColumn(6);
		 			cell.setCellValue(b2.getInt("Box"));
		 			
		 			cell = row.createCell(7);
		 			spreadsheet.autoSizeColumn(7);
		 			cell.setCellValue(b2.getString("ConsignorAddress"));
		 			
		 			cell = row.createCell(8);
		 			spreadsheet.autoSizeColumn(8);
		 			cell.setCellValue(b2.getString("PhoneNo"));
		 			
		 			cell = row.createCell(9);
		 			spreadsheet.autoSizeColumn(9);
		 			cell.setCellValue(b2.getDouble("Amount"));
		 			
		 			cell = row.createCell(10);
		 			spreadsheet.autoSizeColumn(10);
		 			cell.setCellValue(b2.getDouble("FuelSurCharge"));
		 			
		 			cell=row.createCell(11);
		 			spreadsheet.autoSizeColumn(11);
		 			cell.setCellValue(b2.getDouble("Tax"));
		 			
		 			cell=row.createCell(12);
		 			spreadsheet.autoSizeColumn(12);
		 			cell.setCellValue(b2.getDouble("TotalAmount"));
		 			
		 			rowcount++;
		 		}
		 		
		 		
		 		FileOutputStream out = new FileOutputStream(new File("C:/Backup/" + " " + "Report.xls"));
		 		
		 		try {
		 			workbook.write(out);
		 			out.close();
		 		} catch (IOException e) {
		 			// TODO Auto-generated catch block
		 			e.printStackTrace();
		 		}
		 	}
		 else if(to.getEditor().getText().isEmpty() && date.getEditor().getText().isEmpty()  && townname.getEditor().getText().isEmpty() )
			{
				pstmt = con.prepareStatement("select * from airwaybills where Consignor=?");
				pstmt.setString(1, cname.getEditor().getText());
				ResultSet b2 = pstmt.executeQuery();
				
				HSSFWorkbook workbook = new HSSFWorkbook();
		 		HSSFSheet spreadsheet = workbook.createSheet("Backup");
		 		HSSFRow row = spreadsheet.createRow(1);
		 		HSSFCell cell;
		 		cell = row.createCell(1);
		 		spreadsheet.autoSizeColumn(1);
		 		cell.setCellValue("AirwayBill No");
		 		cell = row.createCell(2);
		 		spreadsheet.autoSizeColumn(2);
		 		cell.setCellValue("Date");
		 		cell = row.createCell(3);
		 		spreadsheet.autoSizeColumn(3);
		 		cell.setCellValue("Client Name");
		 		cell = row.createCell(4);
		 		spreadsheet.autoSizeColumn(4);
		 		cell.setCellValue("Destination");
		 		cell = row.createCell(5);
		 		spreadsheet.autoSizeColumn(5);
		 		cell.setCellValue("Weight");
		 		cell = row.createCell(6);
		 		spreadsheet.autoSizeColumn(6);
		 		cell.setCellValue("Box/Piece");
		 		cell = row.createCell(7);
		 		spreadsheet.autoSizeColumn(7);
		 		cell.setCellValue("Client Address");
		 		cell = row.createCell(8);
		 		spreadsheet.autoSizeColumn(8);
		 		cell.setCellValue("PhoneNo");
		 		cell = row.createCell(9);
		 		spreadsheet.autoSizeColumn(9);
		 		cell.setCellValue("Base Value");
		 		cell=row.createCell(10);
		 		spreadsheet.autoSizeColumn(10);
		 		cell.setCellValue("Fuel SurCharge");
		 		cell=row.createCell(11);
		 		spreadsheet.autoSizeColumn(11);
		 		cell.setCellValue("Tax");
		 		cell=row.createCell(12);
		 		spreadsheet.autoSizeColumn(12);
		 		cell.setCellValue("Total Amount");
		 		
		 		int rowcount = 2;
		 		while (b2.next()) 
		 		{
		 			row = spreadsheet.createRow(rowcount);
		 			cell = row.createCell(1);
		 			spreadsheet.autoSizeColumn(1);
		 			cell.setCellValue(b2.getString("AirwayBillNo"));
		 			
		 			cell = row.createCell(2);
		 			spreadsheet.autoSizeColumn(2);
		 			cell.setCellValue(b2.getString("Date"));
		 			
		 			cell = row.createCell(3);
		 			spreadsheet.autoSizeColumn(3);
		 			cell.setCellValue(b2.getString("Consignor"));
		 			
		 			cell = row.createCell(4);
		 			spreadsheet.autoSizeColumn(4);
		 			cell.setCellValue(b2.getString("Place"));
		 			
		 			cell = row.createCell(5);
		 			spreadsheet.autoSizeColumn(5);
		 			cell.setCellValue(b2.getDouble("Weight"));
		 			
		 			cell = row.createCell(6);
		 			spreadsheet.autoSizeColumn(6);
		 			cell.setCellValue(b2.getInt("Box"));
		 			
		 			cell = row.createCell(7);
		 			spreadsheet.autoSizeColumn(7);
		 			cell.setCellValue(b2.getString("ConsignorAddress"));
		 			
		 			cell = row.createCell(8);
		 			spreadsheet.autoSizeColumn(8);
		 			cell.setCellValue(b2.getString("PhoneNo"));
		 			
		 			cell = row.createCell(9);
		 			spreadsheet.autoSizeColumn(9);
		 			cell.setCellValue(b2.getDouble("Amount"));
		 			
		 			cell = row.createCell(10);
		 			spreadsheet.autoSizeColumn(10);
		 			cell.setCellValue(b2.getDouble("FuelSurCharge"));
		 			
		 			cell=row.createCell(11);
		 			spreadsheet.autoSizeColumn(11);
		 			cell.setCellValue(b2.getDouble("Tax"));
		 			
		 			cell=row.createCell(12);
		 			spreadsheet.autoSizeColumn(12);
		 			cell.setCellValue(b2.getDouble("TotalAmount"));
		 			
		 			rowcount++;
		 		}
		 		
		 		
		 		FileOutputStream out = new FileOutputStream(new File("C:/Backup/" + " " + "Report.xls"));
		 		
		 		try {
		 			workbook.write(out);
		 			out.close();
		 		} catch (IOException e) {
		 			// TODO Auto-generated catch block
		 			e.printStackTrace();
		 		}
		 	}
		 
		 
		 
		 else if(to.getEditor().getText().isEmpty() && date.getEditor().getText().isEmpty()  && cname.getEditor().getText().isEmpty())
			{
				
				pstmt = con.prepareStatement("select * from airwaybills where Place=?");
				pstmt.setString(1, townname.getEditor().getText());
				ResultSet b3 = pstmt.executeQuery();
			
				HSSFWorkbook workbook = new HSSFWorkbook();
		 		HSSFSheet spreadsheet = workbook.createSheet("Backup");
		 		HSSFRow row = spreadsheet.createRow(1);
		 		HSSFCell cell;
		 		cell = row.createCell(1);
		 		spreadsheet.autoSizeColumn(1);
		 		cell.setCellValue("AirwayBill No");
		 		cell = row.createCell(2);
		 		spreadsheet.autoSizeColumn(2);
		 		cell.setCellValue("Date");
		 		cell = row.createCell(3);
		 		spreadsheet.autoSizeColumn(3);
		 		cell.setCellValue("Client Name");
		 		cell = row.createCell(4);
		 		spreadsheet.autoSizeColumn(4);
		 		cell.setCellValue("Destination");
		 		cell = row.createCell(5);
		 		spreadsheet.autoSizeColumn(5);
		 		cell.setCellValue("Weight");
		 		cell = row.createCell(6);
		 		spreadsheet.autoSizeColumn(6);
		 		cell.setCellValue("Box/Piece");
		 		cell = row.createCell(7);
		 		spreadsheet.autoSizeColumn(7);
		 		cell.setCellValue("Client Address");
		 		cell = row.createCell(8);
		 		spreadsheet.autoSizeColumn(8);
		 		cell.setCellValue("PhoneNo");
		 		cell = row.createCell(9);
		 		spreadsheet.autoSizeColumn(9);
		 		cell.setCellValue("Base Value");
		 		cell=row.createCell(10);
		 		spreadsheet.autoSizeColumn(10);
		 		cell.setCellValue("Fuel SurCharge");
		 		cell=row.createCell(11);
		 		spreadsheet.autoSizeColumn(11);
		 		cell.setCellValue("Tax");
		 		cell=row.createCell(12);
		 		spreadsheet.autoSizeColumn(12);
		 		cell.setCellValue("Total Amount");
		 		
		 		int rowcount = 2;
		 		while (b3.next()) 
		 		{
		 			row = spreadsheet.createRow(rowcount);
		 			cell = row.createCell(1);
		 			spreadsheet.autoSizeColumn(1);
		 			cell.setCellValue(b3.getString("AirwayBillNo"));
		 			cell = row.createCell(2);
		 			spreadsheet.autoSizeColumn(2);
		 			cell.setCellValue(b3.getString("Date"));
		 			cell = row.createCell(3);
		 			spreadsheet.autoSizeColumn(3);
		 			cell.setCellValue(b3.getString("Consignor"));
		 			cell = row.createCell(4);
		 			spreadsheet.autoSizeColumn(4);
		 			cell.setCellValue(b3.getString("Place"));
		 			cell = row.createCell(5);
		 			spreadsheet.autoSizeColumn(5);
		 			cell.setCellValue(b3.getDouble("Weight"));
		 			cell = row.createCell(6);
		 			spreadsheet.autoSizeColumn(6);
		 			cell.setCellValue(b3.getInt("Box"));
		 			cell = row.createCell(7);
		 			spreadsheet.autoSizeColumn(7);
		 			cell.setCellValue(b3.getString("ConsignorAddress"));
		 			cell = row.createCell(8);
		 			spreadsheet.autoSizeColumn(8);
		 			cell.setCellValue(b3.getString("PhoneNo"));
		 			cell = row.createCell(9);
		 			spreadsheet.autoSizeColumn(9);
		 			cell.setCellValue(b3.getDouble("Amount"));
		 			cell = row.createCell(10);
		 			spreadsheet.autoSizeColumn(10);
		 			cell.setCellValue(b3.getDouble("FuelSurCharge"));
		 			cell=row.createCell(11);
		 			spreadsheet.autoSizeColumn(11);
		 			cell.setCellValue(b3.getDouble("Tax"));
		 			cell=row.createCell(12);
		 			spreadsheet.autoSizeColumn(12);
		 			cell.setCellValue(b3.getDouble("TotalAmount"));
		 			
		 			rowcount++;
		 		}
		 		
		 		FileOutputStream out = new FileOutputStream(new File("C:/Backup/" +" "+   "Report.xls"));
		 		try {
		 			workbook.write(out);
		 			out.close();
		 		} catch (IOException e) {
		 			// TODO Auto-generated catch block
		 			e.printStackTrace();
		 		}
		 	}
		 
		 
		 
		 
		 else if(to.getEditor().getText().isEmpty() && date.getEditor().getText().isEmpty())
			{
				pstmt = con.prepareStatement("select * from airwaybills where Consignor=? and Place=?");
				pstmt.setString(1, cname.getEditor().getText());
				pstmt.setString(2, townname.getEditor().getText());
				ResultSet b1 = pstmt.executeQuery();
	 		
	 		HSSFWorkbook workbook = new HSSFWorkbook();
	 		HSSFSheet spreadsheet = workbook.createSheet("Backup");
	 		HSSFRow row = spreadsheet.createRow(1);
	 		HSSFCell cell;
	 		cell = row.createCell(1);
	 		spreadsheet.autoSizeColumn(1);
	 		cell.setCellValue("AirwayBill No");
	 		cell = row.createCell(2);
	 		spreadsheet.autoSizeColumn(2);
	 		cell.setCellValue("Date");
	 		cell = row.createCell(3);
	 		spreadsheet.autoSizeColumn(3);
	 		cell.setCellValue("Client Name");
	 		cell = row.createCell(4);
	 		spreadsheet.autoSizeColumn(4);
	 		cell.setCellValue("Destination");
	 		cell = row.createCell(5);
	 		spreadsheet.autoSizeColumn(5);
	 		cell.setCellValue("Weight");
	 		cell = row.createCell(6);
	 		spreadsheet.autoSizeColumn(6);
	 		cell.setCellValue("Box/Piece");
	 		cell = row.createCell(7);
	 		spreadsheet.autoSizeColumn(7);
	 		cell.setCellValue("Client Address");
	 		cell = row.createCell(8);
	 		spreadsheet.autoSizeColumn(8);
	 		cell.setCellValue("PhoneNo");
	 		cell = row.createCell(9);
	 		spreadsheet.autoSizeColumn(9);
	 		cell.setCellValue("Base Value");
	 		cell=row.createCell(10);
	 		spreadsheet.autoSizeColumn(10);
	 		cell.setCellValue("Fuel SurCharge");
	 		cell=row.createCell(11);
	 		spreadsheet.autoSizeColumn(11);
	 		cell.setCellValue("Tax");
	 		cell=row.createCell(12);
	 		spreadsheet.autoSizeColumn(12);
	 		cell.setCellValue("Total Amount");
	 		
	 		int rowcount = 2;
	 		while (b1.next()) 
	 		{
	 			row = spreadsheet.createRow(rowcount);
	 			cell = row.createCell(1);
	 			spreadsheet.autoSizeColumn(1);
	 			cell.setCellValue(b1.getString("AirwayBillNo"));
	 			cell = row.createCell(2);
	 			spreadsheet.autoSizeColumn(2);
	 			cell.setCellValue(b1.getString("Date"));
	 			cell = row.createCell(3);
	 			spreadsheet.autoSizeColumn(3);
	 			cell.setCellValue(b1.getString("Consignor"));
	 			cell = row.createCell(4);
	 			spreadsheet.autoSizeColumn(4);
	 			cell.setCellValue(b1.getString("Place"));
	 			cell = row.createCell(5);
	 			spreadsheet.autoSizeColumn(5);
	 			cell.setCellValue(b1.getDouble("Weight"));
	 			cell = row.createCell(6);
	 			spreadsheet.autoSizeColumn(6);
	 			cell.setCellValue(b1.getInt("Box"));
	 			cell = row.createCell(7);
	 			spreadsheet.autoSizeColumn(7);
	 			cell.setCellValue(b1.getString("ConsignorAddress"));
	 			cell = row.createCell(8);
	 			spreadsheet.autoSizeColumn(8);
	 			cell.setCellValue(b1.getString("PhoneNo"));
	 			cell = row.createCell(9);
	 			spreadsheet.autoSizeColumn(9);
	 			cell.setCellValue(b1.getDouble("Amount"));
	 			cell = row.createCell(10);
	 			spreadsheet.autoSizeColumn(10);
	 			cell.setCellValue(b1.getDouble("FuelSurCharge"));
	 			cell=row.createCell(11);
	 			spreadsheet.autoSizeColumn(11);
	 			cell.setCellValue(b1.getDouble("Tax"));
	 			cell=row.createCell(12);
	 			spreadsheet.autoSizeColumn(12);
	 			cell.setCellValue(b1.getDouble("TotalAmount"));
	 			
	 			rowcount++;
	 		}
	 		
	 		FileOutputStream out = new FileOutputStream(new File("C:/Backup/" +" "+ "Report.xls"));
	 		try {
	 			workbook.write(out);
	 			out.close();
	 		} catch (IOException e) {
	 			// TODO Auto-generated catch block
	 			e.printStackTrace();
	 		}
	 	}

			 else if(townname.getEditor().getText().isEmpty())
			{
				LocalDate localDate = date.getValue();
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
				String date = localDate.format(formatter);
				
				LocalDate localDate1 = to.getValue();
				DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("yyyy-MM-dd");
				String to = localDate1.format(formatter1);
				
				pstmt = con.prepareStatement("select * from airwaybills where Consignor=? and Date between ? and ?");
				pstmt.setString(1, cname.getEditor().getText());
				pstmt.setString(2, date);
				pstmt.setString(3, to);
				ResultSet b3 = pstmt.executeQuery();
			
				HSSFWorkbook workbook = new HSSFWorkbook();
		 		HSSFSheet spreadsheet = workbook.createSheet("Backup");
		 		HSSFRow row = spreadsheet.createRow(1);
		 		HSSFCell cell;
		 		cell = row.createCell(1);
		 		spreadsheet.autoSizeColumn(1);
		 		cell.setCellValue("AirwayBill No");
		 		cell = row.createCell(2);
		 		spreadsheet.autoSizeColumn(2);
		 		cell.setCellValue("Date");
		 		cell = row.createCell(3);
		 		spreadsheet.autoSizeColumn(3);
		 		cell.setCellValue("Client Name");
		 		cell = row.createCell(4);
		 		spreadsheet.autoSizeColumn(4);
		 		cell.setCellValue("Destination");
		 		cell = row.createCell(5);
		 		spreadsheet.autoSizeColumn(5);
		 		cell.setCellValue("Weight");
		 		cell = row.createCell(6);
		 		spreadsheet.autoSizeColumn(6);
		 		cell.setCellValue("Box/Piece");
		 		cell = row.createCell(7);
		 		spreadsheet.autoSizeColumn(7);
		 		cell.setCellValue("Client Address");
		 		cell = row.createCell(8);
		 		spreadsheet.autoSizeColumn(8);
		 		cell.setCellValue("PhoneNo");
		 		cell = row.createCell(9);
		 		spreadsheet.autoSizeColumn(9);
		 		cell.setCellValue("Base Value");
		 		cell=row.createCell(10);
		 		spreadsheet.autoSizeColumn(10);
		 		cell.setCellValue("Fuel SurCharge");
		 		cell=row.createCell(11);
		 		spreadsheet.autoSizeColumn(11);
		 		cell.setCellValue("Tax");
		 		cell=row.createCell(12);
		 		spreadsheet.autoSizeColumn(12);
		 		cell.setCellValue("Total Amount");
		 		
		 		int rowcount = 2;
		 		while (b3.next()) 
		 		{
		 			row = spreadsheet.createRow(rowcount);
		 			cell = row.createCell(1);
		 			spreadsheet.autoSizeColumn(1);
		 			cell.setCellValue(b3.getString("AirwayBillNo"));
		 			cell = row.createCell(2);
		 			spreadsheet.autoSizeColumn(2);
		 			cell.setCellValue(b3.getString("Date"));
		 			cell = row.createCell(3);
		 			spreadsheet.autoSizeColumn(3);
		 			cell.setCellValue(b3.getString("Consignor"));
		 			cell = row.createCell(4);
		 			spreadsheet.autoSizeColumn(4);
		 			cell.setCellValue(b3.getString("Place"));
		 			cell = row.createCell(5);
		 			spreadsheet.autoSizeColumn(5);
		 			cell.setCellValue(b3.getDouble("Weight"));
		 			cell = row.createCell(6);
		 			spreadsheet.autoSizeColumn(6);
		 			cell.setCellValue(b3.getInt("Box"));
		 			cell = row.createCell(7);
		 			spreadsheet.autoSizeColumn(7);
		 			cell.setCellValue(b3.getString("ConsignorAddress"));
		 			cell = row.createCell(8);
		 			spreadsheet.autoSizeColumn(8);
		 			cell.setCellValue(b3.getString("PhoneNo"));
		 			cell = row.createCell(9);
		 			spreadsheet.autoSizeColumn(9);
		 			cell.setCellValue(b3.getDouble("Amount"));
		 			cell = row.createCell(10);
		 			spreadsheet.autoSizeColumn(10);
		 			cell.setCellValue(b3.getDouble("FuelSurCharge"));
		 			cell=row.createCell(11);
		 			spreadsheet.autoSizeColumn(11);
		 			cell.setCellValue(b3.getDouble("Tax"));
		 			cell=row.createCell(12);
		 			spreadsheet.autoSizeColumn(12);
		 			cell.setCellValue(b3.getDouble("TotalAmount"));
		 			
		 			rowcount++;
		 		}
		 		
		 		FileOutputStream out = new FileOutputStream(new File("C:/Backup/" +" "+   "Report.xls"));
		 		try {
		 			workbook.write(out);
		 			out.close();
		 		} catch (IOException e) {
		 			// TODO Auto-generated catch block
		 			e.printStackTrace();
		 		}
		 	}

		 
			 else if(cname.getEditor().getText().isEmpty())
				{
					LocalDate localDate = date.getValue();
					DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
					String date = localDate.format(formatter);
					
					LocalDate localDate1 = to.getValue();
					DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("yyyy-MM-dd");
					String to = localDate1.format(formatter1);
					
					pstmt = con.prepareStatement("select * from airwaybills where Place=? and Date between ? and ?");
					pstmt.setString(1, townname.getEditor().getText());
					pstmt.setString(2, date);
					pstmt.setString(3, to);
					ResultSet b3 = pstmt.executeQuery();
				
					HSSFWorkbook workbook = new HSSFWorkbook();
			 		HSSFSheet spreadsheet = workbook.createSheet("Backup");
			 		HSSFRow row = spreadsheet.createRow(1);
			 		HSSFCell cell;
			 		cell = row.createCell(1);
			 		spreadsheet.autoSizeColumn(1);
			 		cell.setCellValue("AirwayBill No");
			 		cell = row.createCell(2);
			 		spreadsheet.autoSizeColumn(2);
			 		cell.setCellValue("Date");
			 		cell = row.createCell(3);
			 		spreadsheet.autoSizeColumn(3);
			 		cell.setCellValue("Client Name");
			 		cell = row.createCell(4);
			 		spreadsheet.autoSizeColumn(4);
			 		cell.setCellValue("Destination");
			 		cell = row.createCell(5);
			 		spreadsheet.autoSizeColumn(5);
			 		cell.setCellValue("Weight");
			 		cell = row.createCell(6);
			 		spreadsheet.autoSizeColumn(6);
			 		cell.setCellValue("Box/Piece");
			 		cell = row.createCell(7);
			 		spreadsheet.autoSizeColumn(7);
			 		cell.setCellValue("Client Address");
			 		cell = row.createCell(8);
			 		spreadsheet.autoSizeColumn(8);
			 		cell.setCellValue("PhoneNo");
			 		cell = row.createCell(9);
			 		spreadsheet.autoSizeColumn(9);
			 		cell.setCellValue("Base Value");
			 		cell=row.createCell(10);
			 		spreadsheet.autoSizeColumn(10);
			 		cell.setCellValue("Fuel SurCharge");
			 		cell=row.createCell(11);
			 		spreadsheet.autoSizeColumn(11);
			 		cell.setCellValue("Tax");
			 		cell=row.createCell(12);
			 		spreadsheet.autoSizeColumn(12);
			 		cell.setCellValue("Total Amount");
			 		
			 		int rowcount = 2;
			 		while (b3.next()) 
			 		{
			 			row = spreadsheet.createRow(rowcount);
			 			cell = row.createCell(1);
			 			spreadsheet.autoSizeColumn(1);
			 			cell.setCellValue(b3.getString("AirwayBillNo"));
			 			cell = row.createCell(2);
			 			spreadsheet.autoSizeColumn(2);
			 			cell.setCellValue(b3.getString("Date"));
			 			cell = row.createCell(3);
			 			spreadsheet.autoSizeColumn(3);
			 			cell.setCellValue(b3.getString("Consignor"));
			 			cell = row.createCell(4);
			 			spreadsheet.autoSizeColumn(4);
			 			cell.setCellValue(b3.getString("Place"));
			 			cell = row.createCell(5);
			 			spreadsheet.autoSizeColumn(5);
			 			cell.setCellValue(b3.getDouble("Weight"));
			 			cell = row.createCell(6);
			 			spreadsheet.autoSizeColumn(6);
			 			cell.setCellValue(b3.getInt("Box"));
			 			cell = row.createCell(7);
			 			spreadsheet.autoSizeColumn(7);
			 			cell.setCellValue(b3.getString("ConsignorAddress"));
			 			cell = row.createCell(8);
			 			spreadsheet.autoSizeColumn(8);
			 			cell.setCellValue(b3.getString("PhoneNo"));
			 			cell = row.createCell(9);
			 			spreadsheet.autoSizeColumn(9);
			 			cell.setCellValue(b3.getDouble("Amount"));
			 			cell = row.createCell(10);
			 			spreadsheet.autoSizeColumn(10);
			 			cell.setCellValue(b3.getDouble("FuelSurCharge"));
			 			cell=row.createCell(11);
			 			spreadsheet.autoSizeColumn(11);
			 			cell.setCellValue(b3.getDouble("Tax"));
			 			cell=row.createCell(12);
			 			spreadsheet.autoSizeColumn(12);
			 			cell.setCellValue(b3.getDouble("TotalAmount"));
			 			
			 			rowcount++;
			 		}
			 		
			 		FileOutputStream out = new FileOutputStream(new File("C:/Backup/" +" "+   "Report.xls"));
			 		try {
			 			workbook.write(out);
			 			out.close();
			 		} catch (IOException e) {
			 			// TODO Auto-generated catch block
			 			e.printStackTrace();
			 		}
			 	}
		 
		 
		 else 
			{

				LocalDate localDate = date.getValue();
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
				String date = localDate.format(formatter);
				
			//	System.out.println(date);
				
				LocalDate localDate1 = to.getValue();
				DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("yyyy-MM-dd");
				String to = localDate1.format(formatter1);
				
				System.out.println(to);
				
				pstmt = con.prepareStatement("select * from airwaybills where Consignor=? and Place=? and Date between ? and ?");
				pstmt.setString(1, cname.getEditor().getText());
				pstmt.setString(2, townname.getEditor().getText());
				pstmt.setString(3, date);
				pstmt.setString(4, to);
				ResultSet b4 = pstmt.executeQuery();
				
				HSSFWorkbook workbook = new HSSFWorkbook();
		 		HSSFSheet spreadsheet = workbook.createSheet("Backup");
		 		HSSFRow row = spreadsheet.createRow(1);
		 		HSSFCell cell;
		 		cell = row.createCell(1);
		 		spreadsheet.autoSizeColumn(1);
		 		cell.setCellValue("AirwayBill No");
		 		cell = row.createCell(2);
		 		spreadsheet.autoSizeColumn(2);
		 		cell.setCellValue("Date");
		 		cell = row.createCell(3);
		 		spreadsheet.autoSizeColumn(3);
		 		cell.setCellValue("Client Name");
		 		cell = row.createCell(4);
		 		spreadsheet.autoSizeColumn(4);
		 		cell.setCellValue("Destination");
		 		cell = row.createCell(5);
		 		spreadsheet.autoSizeColumn(5);
		 		cell.setCellValue("Weight");
		 		cell = row.createCell(6);
		 		spreadsheet.autoSizeColumn(6);
		 		cell.setCellValue("Box/Piece");
		 		cell = row.createCell(7);
		 		spreadsheet.autoSizeColumn(7);
		 		cell.setCellValue("Client Address");
		 		cell = row.createCell(8);
		 		spreadsheet.autoSizeColumn(8);
		 		cell.setCellValue("PhoneNo");
		 		cell = row.createCell(9);
		 		spreadsheet.autoSizeColumn(9);
		 		cell.setCellValue("Base Value");
		 		cell=row.createCell(10);
		 		spreadsheet.autoSizeColumn(10);
		 		cell.setCellValue("Fuel SurCharge");
		 		cell=row.createCell(11);
		 		spreadsheet.autoSizeColumn(11);
		 		cell.setCellValue("Tax");
		 		cell=row.createCell(12);
		 		spreadsheet.autoSizeColumn(12);
		 		cell.setCellValue("Total Amount");
		 		
		 		int rowcount = 2;
		 		while (b4.next()) 
		 		{
		 			row = spreadsheet.createRow(rowcount);
		 			cell = row.createCell(1);
		 			spreadsheet.autoSizeColumn(1);
		 			cell.setCellValue(b4.getString("AirwayBillNo"));
		 			cell = row.createCell(2);
		 			spreadsheet.autoSizeColumn(2);
		 			cell.setCellValue(b4.getString("Date"));
		 			cell = row.createCell(3);
		 			spreadsheet.autoSizeColumn(3);
		 			cell.setCellValue(b4.getString("Consignor"));
		 			cell = row.createCell(4);
		 			spreadsheet.autoSizeColumn(4);
		 			cell.setCellValue(b4.getString("Place"));
		 			cell = row.createCell(5);
		 			spreadsheet.autoSizeColumn(5);
		 			cell.setCellValue(b4.getDouble("Weight"));
		 			cell = row.createCell(6);
		 			spreadsheet.autoSizeColumn(6);
		 			cell.setCellValue(b4.getInt("Box"));
		 			cell = row.createCell(7);
		 			spreadsheet.autoSizeColumn(7);
		 			cell.setCellValue(b4.getString("ConsignorAddress"));
		 			cell = row.createCell(8);
		 			spreadsheet.autoSizeColumn(8);
		 			cell.setCellValue(b4.getString("PhoneNo"));
		 			cell = row.createCell(9);
		 			spreadsheet.autoSizeColumn(9);
		 			cell.setCellValue(b4.getDouble("Amount"));
		 			cell = row.createCell(10);
		 			spreadsheet.autoSizeColumn(10);
		 			cell.setCellValue(b4.getDouble("FuelSurCharge"));
		 			cell=row.createCell(11);
		 			spreadsheet.autoSizeColumn(11);
		 			cell.setCellValue(b4.getDouble("Tax"));
		 			cell=row.createCell(12);
		 			spreadsheet.autoSizeColumn(12);
		 			cell.setCellValue(b4.getDouble("TotalAmount"));
		 			
		 			rowcount++;
		 		}
		 		
		 		FileOutputStream out = new FileOutputStream(new File("C:/Backup/" +" " + "Report.xls"));
		 		try {
		 			workbook.write(out);
		 			out.close();
		 		} catch (IOException e) {
		 			// TODO Auto-generated catch block
		 			e.printStackTrace();
		 		}
		 	}	 
	 }
	 public void select() throws SQLException
	 {
		 list4 = FXCollections.observableArrayList();
			pstmt3 = con.prepareStatement("select distinct TownName from tariffentry where ClientName=?");
			pstmt3.setString(1, cname.getEditor().getText());
			ResultSet result=pstmt3.executeQuery();
			while (result.next()) 
			{
				list4.add(result.getString("TownName"));
			}
			townname.setEditable(true);
			townname.setItems(list4);
			new AutoCompleteComboBoxListener<>(townname);
			
			
			pstmt=con.prepareStatement("select Code from customerdetails where Name=?");
			pstmt.setString(1, cname.getEditor().getText());
			ResultSet code1=pstmt.executeQuery();
			while (code1.next())
			{
				code.setText(code1.getString("Code"));
			}
	 }
}


