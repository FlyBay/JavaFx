package application;

import javafx.beans.property.DoubleProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Tarifftable {

	public SimpleStringProperty pojoclient;
	public SimpleStringProperty pojocode;
	public SimpleStringProperty pojotown;
	public SimpleDoubleProperty pojokg;
	public SimpleStringProperty pojotownname;
	public SimpleDoubleProperty pojofuel;
	public Tarifftable(String pojoclient,String pojocode,String pojotown,Double pojokg,String pojotownname,Double pojofuel) {
		this.pojoclient =new SimpleStringProperty(pojoclient);
		this.pojocode =new SimpleStringProperty(pojocode);
		this.pojotown =new SimpleStringProperty(pojotown);
		this.pojokg=new SimpleDoubleProperty(pojokg);
		this.pojotownname =new SimpleStringProperty(pojotownname);
		this.pojofuel =new SimpleDoubleProperty(pojofuel);
		}
	public StringProperty pojoclientProperty(){
		return pojoclient;
	}
	public StringProperty pojocodeProperty(){
		return pojocode;
	}
	public StringProperty pojotownProperty() {
		return pojotown;
	}
	public  DoubleProperty pojokgProperty() {
		return pojokg;
	}
	public StringProperty pojotownnameProperty() {
		return pojotownname;
	}
	public  DoubleProperty pojofuelProperty() {
		return pojofuel;
	}
}
	
