package application;
import javafx.beans.InvalidationListener;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;


public class Towntable {
	public SimpleStringProperty pojotname;
	public SimpleStringProperty pojotcode;
	
	public Towntable( String pojotname, String pojotcode){
		this.pojotname=new SimpleStringProperty(pojotname);
		this.pojotcode=new SimpleStringProperty(pojotcode);
		
	}
	public StringProperty pojotnameProperty(){
		return pojotname;
	}
	public StringProperty pojotcodeProperty() {
		return pojotcode;
	}

}
