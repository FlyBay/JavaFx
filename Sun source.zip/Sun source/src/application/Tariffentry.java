package application;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.StringTokenizer;

import javax.swing.JOptionPane;
import javax.swing.JPanel;

import com.sun.javafx.scene.control.SelectedCellsMap;

import javafx.application.Platform;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TablePosition;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRResultSetDataSource;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.view.JasperViewer;

public class Tariffentry implements Initializable{
	public TextField clientcode,perkg,fscharge;
	public ComboBox cname,town;
	Connection connect;
	PreparedStatement pstmt,pstmt1,pst,pstmt4,pstmt3,pstm,jas;
	ResultSet rs, rs1, rs2,rs4,rs3,rs5,ja;
	Statement stmt, stmt1;
	public TableView tariff;
	 public TableColumn<Tarifftable,String>tclient,tariffcode,tname,tcode;
	 public  TableColumn<Tarifftable,Double>tariffkg,tf;
	 ObservableList<Tarifftable> list2 = FXCollections.observableArrayList();
	 
	 
	public void initialize(URL arg0, ResourceBundle arg1) 
	{
		
		
		ObservableList list = FXCollections.observableArrayList();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/sun", "root", "root");
			stmt=connect.createStatement();
			rs=stmt.executeQuery("select * from customerdetails");
			while (rs.next()) {
				list.add(rs.getString("Name"));
				cname.setEditable(true);
				cname.setItems(list);
				
				new AutoCompleteComboBoxListener<>(cname);
				
			}
		}
		
			catch (ClassNotFoundException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
			catch (SQLException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();

			}
		
		
		ObservableList list1 = FXCollections.observableArrayList();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/sun", "root", "root");
			stmt1=connect.createStatement();
			rs1=stmt1.executeQuery("select * from townname");
			while (rs1.next()) {
				list1.add(rs1.getString("Code"));
				town.setEditable(true);
				town.setItems(list1);
				new AutoCompleteComboBoxListener<>(town);
				
			}
		}
		
			catch (ClassNotFoundException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
			catch (SQLException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();

			}
		
				try {
					pstmt = connect.prepareStatement("select * from tariffentry order by ClientName");
					rs1 = pstmt.executeQuery();
				
				while (rs1.next()) 
				{
					list2.add(new Tarifftable(rs1.getString("ClientName"),rs1.getString("Code"),rs1.getString("TownCode"),rs1.getDouble("perKg"),rs1.getString("TownName"),rs1.getDouble("Fuel")));
				//System.out.println(rs1.getDouble("Fuel"));
				}
				tclient.setCellValueFactory(new PropertyValueFactory<Tarifftable, String>("pojoclient"));
				tariffcode.setCellValueFactory(new PropertyValueFactory<Tarifftable, String>("pojocode"));
				tcode.setCellValueFactory(new PropertyValueFactory<Tarifftable, String>("pojotown"));
				tariffkg.setCellValueFactory(new PropertyValueFactory<Tarifftable, Double>("pojokg"));
				tname.setCellValueFactory(new PropertyValueFactory<Tarifftable, String>("pojotownname"));
				tf.setCellValueFactory(new PropertyValueFactory<Tarifftable, Double>("pojofuel"));
				tariff.setItems(list2);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
						
		}
		
	public void view() throws SQLException, JRException
	{
		jas=connect.prepareStatement("select * from tariffentry");
		ja = jas.executeQuery();
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("ReportTitle", "PDF JasperReport");
			
		JRResultSetDataSource jasp=new JRResultSetDataSource(ja);
	
		JasperPrint jasperPrint = JasperFillManager.fillReport("C:/jasper/Tariff.jasper", parameters,jasp);
		JasperViewer viewer = new JasperViewer(jasperPrint);
		viewer.setTitle("Tarrif Details");
		viewer.viewReport(jasperPrint, false);
	}
	
		public void tariffadd() throws SQLException, ClassNotFoundException
		{
			
			pstmt = connect.prepareStatement( "insert into Tariffentry(ClientName,Code,TownCode,Perkg,Fuel)Values(?,?,?,?,?)");
			pstmt.setString(1, cname.getEditor().getText());
			pstmt.setString(2, clientcode.getText());
			pstmt.setString(3,town.getEditor().getText());
			pstmt.setString(4,perkg.getText());
			pstmt.setString(5,fscharge.getText());
			int jega = pstmt.executeUpdate();
			
			town();
			clear1();
			initialize(null,null);
			clear();	
		}
		
		public void town() throws ClassNotFoundException, SQLException 
		{
			Class.forName("com.mysql.jdbc.Driver");
			connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/sun", "root", "root");	
			pstmt3=connect.prepareStatement("select * from townname where Code=?");
			pstmt3.setString(1, town.getEditor().getText());
			rs3=pstmt3.executeQuery();
			while(rs3.next())
			{
				String name=rs3.getString("Name");
				System.out.println(name);
				pstm=connect.prepareStatement("update tariffentry set TownName=? where ClientName=? and TownCode=?");
				pstm.setString(1, name);
				pstm.setString(2, cname.getEditor().getText());
				pstm.setString(3,town.getEditor().getText());				
				int vishnu = pstm.executeUpdate();	
			}
		}
		
public void clear1()
		{
			
			for (int i=0;i< tariff.getItems().size();i++)
			{
				tariff.getItems().clear();
			}
		}
		
		
public void clear()
		{
			clear1();
			initialize(null,null);
			cname.getSelectionModel().clearSelection();
			cname.getEditor().clear();
			clientcode.clear();
			town.getEditor().clear();
			perkg.clear();
			fscharge.clear();
		}
public void update() throws SQLException
{
	pstmt1 = connect.prepareStatement("update tariffentry set perKg=?,Fuel=? where Code=? and TownCode=?");
	pstmt1.setString(1,perkg.getText());
	pstmt1.setString(2,fscharge.getText());
	pstmt1.setString(3,clientcode.getText());
	pstmt1.setString(4,town.getEditor().getText());
	pstmt1.executeUpdate() ;
	clear1();
	initialize(null,null);
	clear();
	
		
	}
public void delete()
{
	try
	{
		Alert alert = new Alert(AlertType.CONFIRMATION);
		alert.setTitle("Confirmation Dialog");
		alert.setHeaderText("Do You Want To Delete");
		
		Optional<ButtonType> result = alert.showAndWait();
		if (result.get() == ButtonType.OK){
			pst=connect.prepareStatement("delete from tariffentry where Code=? and TownCode=?");
			pst.setString(1, clientcode.getText());
			pst.setString(2, town.getEditor().getText());
			pst.executeUpdate();
		
			   Alert alert1=new Alert(AlertType.INFORMATION);
				alert1.setContentText("Deleted Successfully");
	            alert1.show();
		}
}
	catch(Exception e)
	{
	e.printStackTrace();
	}
	clear();
	clear1();
	initialize(null,null);
	}
public void click()
{
	Tarifftable retrive=(Tarifftable) tariff.getSelectionModel().getSelectedItem();
	cname.getEditor().setText(retrive.pojoclient.get());
	clientcode.setText(retrive.pojocode.get());
	town.getEditor().setText(retrive.pojotown.get());
	perkg.setText(Double.toString(retrive.pojokg.get()));
	perkg.setText(Double.toString(retrive.pojokg.get()));
	fscharge.setText(Double.toString(retrive.pojofuel.get()));
}

public void client() throws SQLException 
{
	pstmt4 = connect.prepareStatement("select Code from customerdetails where Name=?");
	pstmt4.setString(1, cname.getEditor().getText());
	rs4 = pstmt4.executeQuery();
	while (rs4.next())
	{
	String c = rs4.getString("Code");
	clientcode.setText(c);
	}	
	
}
	
}


	
